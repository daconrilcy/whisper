include!("tests/archive_and_contracts.rs");
include!("tests/recovery.rs");
include!("tests/campaign.rs");
include!("tests/replacement_and_segmented.rs");
include!("tests/publication_characterization.rs");
include!("tests/export_ownership_characterization.rs");
include!("tests/recovery_characterization.rs");
include!("tests/cleanup_characterization.rs");
#[cfg(windows)]
mod cleanup_equivalence;
