use super::*;
use std::thread;
use whisper_core::{
    ComputeChoice, JobConfig, LanguageChoice,
    parakeet_session::TranscriptionStrategy,
    ports::ImportRequest,
};

const CHILD_ROOT: &str = "WHISPER_POLL_PARAKEET_EQ_CHILD_ROOT";

fn compile_worker(root: &Path, name: &str, source: &str) -> PathBuf {
    let source_path = root.join(format!("{name}.rs"));
    let executable = root.join(format!("{name}.exe"));
    fs::write(&source_path, source).expect("write Parakeet worker fixture");
    let output = Command::new("rustc")
        .args(["--edition=2021", "--crate-name", name.replace('-', "_").as_str()])
        .arg(source_path)
        .arg("-o")
        .arg(&executable)
        .output()
        .expect("compile Parakeet worker fixture");
    assert!(
        output.status.success(),
        "rustc {name}: {}",
        String::from_utf8_lossy(&output.stderr)
    );
    executable
}

fn personal_import_request(root: &Path, model: &Path) -> ImportRequest {
    let source = root.join("source.wav");
    let mut writer = crate::parakeet_audio::PcmPartWriter::create(&source)
        .expect("create one-second Parakeet PCM source");
    writer
        .append(&vec![0_i16; 16_000])
        .expect("write synthetic source samples");
    writer.finish().expect("close source WAV");
    let model_record = whisper_core::model_registry::model(
        whisper_core::model_catalog::ModelId::ParakeetTdt06BV3,
    );
    let model_sha256 = (0..32)
        .map(|index| {
            u8::from_str_radix(&model_record.artifact.sha256[index * 2..index * 2 + 2], 16)
                .expect("registered model SHA is hexadecimal")
        })
        .collect::<Vec<_>>()
        .try_into()
        .expect("registered model SHA has 32 bytes");
    let source_sha = crate::archive::sha256_file(&source).expect("hash synthetic source");
    let source_sha256 = (0..32)
        .map(|index| {
            u8::from_str_radix(&source_sha[index * 2..index * 2 + 2], 16)
                .expect("source SHA is hexadecimal")
        })
        .collect::<Vec<_>>()
        .try_into()
        .expect("source SHA has 32 bytes");
    ImportRequest {
        strategy: TranscriptionStrategy::LegacyV1,
        job_id: JobId(73_221),
        generation: Generation::first(),
        source_path: source.to_string_lossy().into_owned(),
        source_sha256: Some(source_sha256),
        source_samples: Some(16_000),
        model_path: model.to_string_lossy().into_owned(),
        model_sha256,
        destination: root.join("archive").to_string_lossy().into_owned(),
        config: JobConfig {
            language: LanguageChoice::Automatic,
            compute: ComputeChoice::Auto,
        },
    }
}

#[test]
fn poll_parakeet_gpu_failure_falls_back_to_qualified_cpu_fixture() {
    if let Some(root) = std::env::var_os(CHILD_ROOT) {
        run_personal_cpu_fallback_child(Path::new(&root));
        return;
    }

    let root = TestRoot::new("parakeet-equivalence-child");
    let model = std::env::var_os("N1_TEST_PERSONAL_PARAKEET_MODEL")
        .map(PathBuf::from)
        .expect("guard supplies the validated Personal Parakeet model");
    let local_app_data = root.0.join("isolated-localappdata");
    let runtime_root = local_app_data.join("Whisper");
    let output = Command::new(std::env::current_exe().expect("test executable path"))
        .arg("--exact")
        .arg("worker_ipc::runtime::poll::tests::parakeet_equivalence::poll_parakeet_gpu_failure_falls_back_to_qualified_cpu_fixture")
        .arg("--nocapture")
        .env(CHILD_ROOT, &root.0)
        .env("LOCALAPPDATA", &local_app_data)
        .env("PARAKEET_L2_RUNTIME_ROOT", &runtime_root)
        .env(
            "PARAKEET_L2_MODEL",
            runtime_root.join("models/parakeet-tdt-0.6b-v3.q8_0.gguf"),
        )
        .env(
            "PARAKEET_L2_CPU_WORKER",
            runtime_root.join("worker/whisper-worker-parakeet-cpu.exe"),
        )
        .env("PARAKEET_L2_CPU_NATIVE_DIR", runtime_root.join("native/cpu"))
        .env("N1_TEST_PERSONAL_PARAKEET_MODEL", model)
        .output()
        .expect("run isolated Parakeet fallback child");
    assert!(
        output.status.success(),
        "Q03 child failed:\n{}\n{}",
        String::from_utf8_lossy(&output.stdout),
        String::from_utf8_lossy(&output.stderr)
    );
    assert!(
        String::from_utf8_lossy(&output.stdout).contains("1 passed; 0 failed"),
        "Q03 child did not execute exactly one test:\n{}",
        String::from_utf8_lossy(&output.stdout)
    );
}

fn run_personal_cpu_fallback_child(root: &Path) {
    let model_source = PathBuf::from(
        std::env::var_os("N1_TEST_PERSONAL_PARAKEET_MODEL")
            .expect("guard supplies the validated Personal Parakeet model"),
    );
    let install_root = model_source
        .parent()
        .and_then(Path::parent)
        .expect("model lives under the personal Whisper installation");
    let local_app_data = root.join("isolated-localappdata");
    let runtime_root = local_app_data.join("Whisper");
    let worker_dir = runtime_root.join("worker");
    let cpu_native = runtime_root.join("native/cpu");
    let gpu_native = runtime_root.join("native/gpu");
    let model_path = runtime_root.join("models/parakeet-tdt-0.6b-v3.q8_0.gguf");
    fs::create_dir_all(&worker_dir).expect("create isolated worker directory");
    fs::create_dir_all(&cpu_native).expect("create isolated CPU runtime directory");
    fs::create_dir_all(&gpu_native).expect("create isolated GPU runtime directory");
    fs::create_dir_all(model_path.parent().expect("model parent"))
        .expect("create isolated model directory");
    fs::copy(&model_source, &model_path).expect("copy verified model into isolated fixture");
    for name in [
        "nemo_speech_asr_c.dll",
        "nemo_speech_asr.dll",
        "ggml.dll",
        "ggml-base.dll",
        "ggml-cpu.dll",
    ] {
        fs::copy(install_root.join("native/cpu").join(name), cpu_native.join(name))
            .expect("copy CPU runtime DLL as read-only qualification data");
    }

    let ready_identity = root.join("cpu-ready-identity.json");
    let transcribe_marker = root.join("cpu-transcribe.jsonl");
    let ready_identity_literal = serde_json::to_string(&ready_identity.to_string_lossy().to_string())
        .expect("encode identity path");
    let transcribe_marker_literal =
        serde_json::to_string(&transcribe_marker.to_string_lossy().to_string())
            .expect("encode transcribe marker path");
    let cpu_source = format!(
        r###"
use std::{{fs::OpenOptions, io::{{self, BufRead, Write}}}};
const IDENTITY: &str = {ready_identity_literal};
const MARKER: &str = {transcribe_marker_literal};
fn main() {{
    let ready = std::fs::read_to_string(IDENTITY).expect("fixture identity");
    let mut frame = String::from(r#"{{"version":1,"message":{{"type":"ready","identity":{{"#);
    frame.push_str(&ready);
    frame.push_str(r#"}},"backend":"CPU","native_version":"fixture"}}}}"#);
    println!("{{frame}}");
    let _ = io::stdout().flush();
    for line in io::stdin().lock().lines().flatten() {{
        if line.contains("\"type\":\"transcribe\"") {{
            let mut file = OpenOptions::new().create(true).append(true).open(MARKER).expect("marker");
            writeln!(file, "{{line}}").expect("record CPU transcribe");
        }}
        if line.contains("\"type\":\"shutdown\"") {{ break; }}
    }}
}}
"###
    );
    let cpu_worker = compile_worker(&worker_dir, "whisper-worker-parakeet-cpu", &cpu_source);
    let cpu_paths = crate::parakeet_import::ParakeetWorkerPaths {
        executable: cpu_worker,
        native_dir: cpu_native,
        model: model_path.clone(),
        runtime_root: runtime_root.clone(),
    };
    let key = cpu_paths
        .qualification_key(whisper_core::parakeet_ipc::PARAKEET_PROFILE_IMPORT_SINGLE_PASS)
        .expect("dynamic isolated personal CPU qualification key");
    let identity = format!(
        r#""model_sha256":"{}","runtime_sha256":"{}","build_sha256":"{}","profile":"{}""#,
        key.artifact_revision, key.runtime_build, key.worker_build, key.inference_profile
    );
    fs::write(&ready_identity, identity).expect("write dynamic CPU READY identity");

    let gpu_worker_source = r###"
use std::{io::{self, BufRead, Write}};
fn main() {
    println!("{}", r#"{"version":1,"message":{"type":"failed","request_id":1,"job_id":"00000000000000000000000000011d75","generation":1,"attempt":1,"identity":null,"code":"BackendUnavailable","message":"synthetic pre-audio GPU failure"}}"#);
    let _ = io::stdout().flush();
    for line in io::stdin().lock().lines().flatten() { if line.contains("\"type\":\"shutdown\"") { break; } }
}
"###;
    let gpu_worker = compile_worker(&worker_dir, "whisper-worker-parakeet-gpu", &gpu_worker_source);
    let gpu_paths = crate::parakeet_import::ParakeetWorkerPaths {
        executable: gpu_worker,
        native_dir: gpu_native,
        model: model_path.clone(),
        runtime_root: runtime_root.clone(),
    };
    let model_record = whisper_core::model_registry::model(
        whisper_core::model_catalog::ModelId::ParakeetTdt06BV3,
    );
    assert_eq!(
        crate::model_catalog::cached_model_sha256(&model_path)
            .expect("verify copied model")
            .1
            .iter()
            .map(|byte| format!("{byte:02x}"))
            .collect::<String>(),
        model_record.artifact.sha256
    );

    let request = personal_import_request(root, &model_path);
    let mut runtime = runtime_with_active_attempt(request.job_id);
    runtime.archive = crate::archive::ArchiveStore::new(&request.destination);
    runtime
        .archive
        .prepare_with_qualification(
            request.clone(),
            None,
            Some(crate::archive::ArchiveQualificationKey::parakeet_gpu_test()),
        )
        .expect("prepare replaceable GPU pending import");
    runtime.parakeet_paths = Some(cpu_paths);
    runtime.parakeet = Some(
        crate::parakeet_import::ParakeetProcess::spawn(&gpu_paths)
            .expect("spawn synthetic GPU worker"),
    );
    runtime.active = Some(crate::worker_ipc::runtime::ImportRequestState {
        job_id: request.job_id,
        generation: request.generation,
        instance_id: 7,
        backend: BackendKind::Cuda,
        attempt_number: 1,
        import_request: Some(request.clone()),
        recovery: crate::worker_ipc::runtime::LiveRecoveryState::None,
        startup_ready: false,
        gpu_candidate: None,
        gpu_attested: false,
    });

    let deadline = Instant::now() + Duration::from_secs(8);
    let mut fallback_completed = false;
    while Instant::now() < deadline && !fallback_completed {
        match runtime.poll_parakeet_worker() {
            Some(Err(error)) => panic!("GPU Failed or CPU fallback failed: {error:?}"),
            Some(Ok(event)) => panic!("unexpected event before CPU READY: {event:?}"),
            None if runtime.active.as_ref().is_some_and(|active| active.backend == BackendKind::Cpu) => {
                fallback_completed = true;
            }
            None => thread::sleep(Duration::from_millis(2)),
        }
    }
    assert!(fallback_completed, "GPU failure must start the CPU attempt");
    assert_eq!(runtime.active.as_ref().expect("CPU attempt").backend, BackendKind::Cpu);
    assert_eq!(runtime.active.as_ref().expect("CPU attempt").attempt_number, 1);
    assert!(runtime.auto_fallback_reason.as_deref().is_some_and(|reason| reason.contains("GPU worker failed before native inference")));

    let ready_deadline = Instant::now() + Duration::from_secs(8);
    let mut cpu_ready = false;
    while Instant::now() < ready_deadline && !cpu_ready {
        match runtime.poll_parakeet_worker() {
            Some(Ok(WorkerEvent::Ready { job_id, generation, backend, .. })) => {
                assert_eq!(job_id, request.job_id);
                assert_eq!(generation, request.generation);
                assert_eq!(backend, BackendKind::Cpu);
                cpu_ready = true;
            }
            Some(Err(error)) => panic!("CPU READY/Transcribe failed: {error:?}"),
            Some(Ok(event)) => panic!("unexpected CPU event: {event:?}"),
            None => thread::sleep(Duration::from_millis(2)),
        }
    }
    assert!(cpu_ready, "qualified fake CPU worker must reach READY");
    let marker_deadline = Instant::now() + Duration::from_secs(3);
    while Instant::now() < marker_deadline && !transcribe_marker.is_file() {
        thread::sleep(Duration::from_millis(2));
    }
    let transcribe = fs::read_to_string(&transcribe_marker).expect("CPU Transcribe wire marker");
    assert_eq!(transcribe.lines().count(), 1, "exactly one CPU Transcribe");
    assert!(transcribe.contains(&format!("\"job_id\":\"{:032x}\"", request.job_id.0)));
    assert!(!runtime.parakeet_native_call_started, "fixture never enters native inference");
    assert!(runtime.auto_fallback_reason.is_some());
    let pending_path = Path::new(&request.destination)
        .join("transcriptions")
        .join(format!("{:032x}", request.job_id.0))
        .join(request.generation.get().to_string())
        .join("pending.json");
    let pending: serde_json::Value =
        serde_json::from_slice(&fs::read(pending_path).expect("read persisted pending record"))
            .expect("decode persisted pending record");
    let cpu_key = runtime.parakeet_paths.as_ref().expect("CPU paths")
        .qualification_key(whisper_core::parakeet_ipc::PARAKEET_PROFILE_IMPORT_SINGLE_PASS)
        .expect("CPU qualification key");
    assert_eq!(pending["qualification"], serde_json::to_value(cpu_key).expect("serialize CPU key"));
}
