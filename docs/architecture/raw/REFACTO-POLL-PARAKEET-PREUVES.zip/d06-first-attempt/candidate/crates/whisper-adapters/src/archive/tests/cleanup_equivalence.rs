use super::super::*;
use super::*;

fn cleanup_relative(root: &Path, path: &Path) -> String {
    path.strip_prefix(root)
        .unwrap()
        .to_string_lossy()
        .into_owned()
}

fn cleanup_fixture(root: &Path, unowned_obstacle: bool) -> CleanupPlan {
    use crate::windows_file_identity::inspect;

    let source_path = root.join("source.wav");
    let mut writer = crate::parakeet_audio::PcmPartWriter::create(&source_path).unwrap();
    writer.append(&vec![0_i16; 160]).unwrap();
    writer.finish().unwrap();
    let source_sha256 = hex(&sha256_file(&source_path).unwrap());

    let successor = TreatmentIdentity {
        destination: root.canonicalize().unwrap().to_string_lossy().into_owned(),
        job_id: JobId(0x7401),
        generation: Generation::first(),
    };
    let successor_path = generation_path(root, successor.job_id, successor.generation);
    fs::create_dir_all(&successor_path).unwrap();
    fs::write(successor_path.join("transcript.txt"), b"new transcript").unwrap();
    fs::write(successor_path.join("transcript.srt"), b"new subtitle\n").unwrap();
    fs::write(successor_path.join("segments.jsonl"), b"").unwrap();
    let pending = PendingRecord {
        version: 4,
        job_id: successor.job_id,
        generation: successor.generation,
        source_path: source_path.to_string_lossy().into_owned(),
        source_sha256: source_sha256.clone(),
        source_samples: 160,
        model_path: "synthetic-model.gguf".into(),
        model_sha256: APPROVED_MODEL_SHA256.into(),
        model_size: APPROVED_MODEL_SIZE,
        strategy: whisper_core::parakeet_session::TranscriptionStrategy::LegacyV1,
        qualification: None,
    };
    fs::write(
        successor_path.join("pending.json"),
        serde_json::to_vec(&pending).unwrap(),
    )
    .unwrap();
    let text = verified_artifact(&successor_path, &successor_path.join("transcript.txt")).unwrap();
    let srt = verified_artifact(&successor_path, &successor_path.join("transcript.srt")).unwrap();
    fs::write(
        successor_path.join("manifest.json"),
        serde_json::to_vec(&CompleteRecord {
            version: 1,
            job_id: successor.job_id,
            generation: successor.generation,
            source_sha256: source_sha256.clone(),
            segments: 0,
            text,
            srt,
        })
        .unwrap(),
    )
    .unwrap();
    let cleanup_id = "cleanup-equivalence";
    fs::write(
        successor_path.join("r11-publication.json"),
        serde_json::to_vec(&PublicationIntent {
            version: 1,
            operation_id: cleanup_id.into(),
            choice: DuplicateImportChoice::Replace,
            source_sha256: source_sha256.clone(),
            source_samples: 160,
            expected_active: Vec::new(),
            export_basename: "fixture".into(),
            internal_only: true,
            cleanup_id: Some(cleanup_id.into()),
            cleanup_targets: Vec::new(),
        })
        .unwrap(),
    )
    .unwrap();
    fs::write(successor_path.join("CURRENT"), b"manifest.json\n").unwrap();
    let index = PublicationIndex {
        version: 1,
        records: vec![PublicationRecord {
            job_id: successor.job_id,
            generation: successor.generation,
            source_sha256: source_sha256.clone(),
            export_basename: Some("fixture".into()),
            active: true,
            success_ordinal: Some(1),
        }],
    };
    write_publication_index(root, &index).unwrap();

    let old_job = JobId(0x7402);
    let old_directory = generation_path(root, old_job, Generation::first());
    fs::create_dir_all(&old_directory).unwrap();
    let owned_file = old_directory.join("owned.txt");
    fs::write(&owned_file, b"owned old artifact").unwrap();
    let mut objects = vec![CleanupObject {
        relative_path: cleanup_relative(root, &owned_file),
        identity: identity_snapshot(inspect(&owned_file, false).unwrap()).unwrap(),
        sha256: Some(hex(&sha256_file(&owned_file).unwrap())),
        owned: true,
        removed: false,
        error: None,
    }];
    if unowned_obstacle {
        let obstacle = old_directory.join("unselected.txt");
        fs::write(&obstacle, b"third party").unwrap();
        objects.push(CleanupObject {
            relative_path: cleanup_relative(root, &obstacle),
            identity: identity_snapshot(inspect(&obstacle, false).unwrap()).unwrap(),
            sha256: Some(hex(&sha256_file(&obstacle).unwrap())),
            owned: false,
            removed: false,
            error: Some("fixture obstacle".into()),
        });
    }
    objects.push(CleanupObject {
        relative_path: cleanup_relative(root, &old_directory),
        identity: identity_snapshot(inspect(&old_directory, true).unwrap()).unwrap(),
        sha256: None,
        owned: true,
        removed: false,
        error: None,
    });
    let old_container = old_directory.parent().unwrap();
    let target = CleanupTarget {
        treatment: TreatmentIdentity {
            destination: successor.destination.clone(),
            job_id: old_job,
            generation: Generation::first(),
        },
        source_sha256: source_sha256.clone(),
        ancestors: [root.join("transcriptions"), old_container.to_path_buf()]
            .into_iter()
            .map(|path| CleanupAncestor {
                relative_path: cleanup_relative(root, &path),
                identity: identity_snapshot(inspect(&path, true).unwrap()).unwrap(),
            })
            .collect(),
        objects,
        container: Some(CleanupObject {
            relative_path: cleanup_relative(root, old_container),
            identity: identity_snapshot(inspect(old_container, true).unwrap()).unwrap(),
            sha256: None,
            owned: true,
            removed: false,
            error: None,
        }),
    };
    let targets = vec![target];
    let intent_path = successor_path.join("r11-publication.json");
    let mut intent: PublicationIntent =
        serde_json::from_slice(&fs::read(intent_path).unwrap()).unwrap();
    intent.cleanup_targets = targets.clone();
    fs::write(
        successor_path.join("r11-publication.json"),
        serde_json::to_vec(&intent).unwrap(),
    )
    .unwrap();

    let mut successor_files = capture_successor_files(root, &successor_path).unwrap();
    successor_files.push(capture_cleanup_file(root, &successor_path.join("CURRENT")).unwrap());
    let mut plan = CleanupPlan {
        version: 1,
        cleanup_id: cleanup_id.into(),
        destination: successor.destination,
        source_path: source_path.to_string_lossy().into_owned(),
        source_sha256,
        successor: successor.clone(),
        successor_directory: identity_snapshot(inspect(&successor_path, true).unwrap()).unwrap(),
        successor_files,
        successor_index: Some(capture_cleanup_file(root, &publication_index_path(root)).unwrap()),
        published: true,
        targets,
        last_error: None,
    };
    write_cleanup_plan(root, &plan).unwrap();
    plan
}

#[test]
fn cleanup_characterization_nonempty_generation_persists_partial_removal_and_resumes() {
    let root = archive_characterization_root("cleanup-d06");
    let plan = cleanup_fixture(&root, true);
    let target = &plan.targets[0];
    let owned = safe_cleanup_path(&root, &target.objects[0].relative_path).unwrap();
    let obstacle = safe_cleanup_path(&root, &target.objects[1].relative_path).unwrap();
    let generation_dir = safe_cleanup_path(&root, &target.objects[2].relative_path).unwrap();

    let first = ArchiveStore::resume_replacement_cleanup(&root, &plan.cleanup_id).unwrap_err();
    assert!(first.starts_with("StorageUnavailable:"), "{first}");
    assert!(
        !owned.exists(),
        "the owned file is removed before directory disposition"
    );
    assert!(obstacle.exists(), "the unowned file is retained");
    assert!(
        generation_dir.is_dir(),
        "the nonempty generation directory remains"
    );
    let persisted = read_cleanup_plan(&root, &plan.cleanup_id).unwrap();
    assert!(persisted.targets[0].objects[0].removed);
    assert!(!persisted.targets[0].objects[1].removed);
    assert!(persisted.last_error.is_some());

    fs::remove_file(&obstacle).unwrap();
    ArchiveStore::resume_replacement_cleanup(&root, &plan.cleanup_id).unwrap();
    let resumed = read_cleanup_plan(&root, &plan.cleanup_id).unwrap();
    assert!(
        resumed.targets[0]
            .objects
            .iter()
            .all(|object| object.removed)
    );
    assert!(resumed.targets[0].container.as_ref().unwrap().removed);
    assert!(resumed.last_error.is_none());
    assert!(!generation_dir.exists());
    assert!(!generation_dir.parent().unwrap().exists());
}
