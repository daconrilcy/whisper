use super::*;
use std::thread;
use whisper_core::{
    ComputeChoice, JobConfig, LanguageChoice, parakeet_session::TranscriptionStrategy,
    ports::ImportRequest,
};

#[cfg(feature = "personal-qualification")]
const CHILD_ROOT: &str = "WHISPER_POLL_PARAKEET_EQ_CHILD_ROOT";
const Q03_JOB_ID: JobId = JobId(73_221);

fn compile_worker(root: &Path, name: &str, source: &str) -> PathBuf {
    let source_path = root.join(format!("{name}.rs"));
    let executable = root.join(format!("{name}.exe"));
    fs::write(&source_path, source).expect("write Parakeet worker fixture");
    let output = Command::new("rustc")
        .args([
            "--edition=2021",
            "--crate-name",
            name.replace('-', "_").as_str(),
        ])
        .arg(source_path)
        .arg("-o")
        .arg(&executable)
        .output()
        .expect("compile Parakeet worker fixture");
    assert!(
        output.status.success(),
        "rustc {name}: {}",
        String::from_utf8_lossy(&output.stderr)
    );
    executable
}

#[cfg(feature = "personal-qualification")]
fn compile_worker_relative(
    root: &Path,
    crate_name: &str,
    source_name: &str,
    executable_name: &str,
    source: &str,
) -> PathBuf {
    fs::write(root.join(source_name), source).expect("write relative worker source");
    let output = Command::new("rustc")
        .current_dir(root)
        .args(["--edition=2021", "--crate-name", crate_name])
        .arg(source_name)
        .arg("-o")
        .arg(executable_name)
        .output()
        .expect("compile relative worker fixture");
    assert!(
        output.status.success(),
        "rustc {crate_name}: {}",
        String::from_utf8_lossy(&output.stderr)
    );
    root.join(executable_name)
}

fn personal_import_request(root: &Path, model: &Path) -> ImportRequest {
    let source = root.join("source.wav");
    let mut writer = crate::parakeet_audio::PcmPartWriter::create(&source)
        .expect("create one-second Parakeet PCM source");
    writer
        .append(&vec![0_i16; 16_000])
        .expect("write synthetic source samples");
    writer.finish().expect("close source WAV");
    let model_record =
        whisper_core::model_registry::model(whisper_core::model_catalog::ModelId::ParakeetTdt06BV3);
    let model_sha256 = (0..32)
        .map(|index| {
            u8::from_str_radix(&model_record.artifact.sha256[index * 2..index * 2 + 2], 16)
                .expect("registered model SHA is hexadecimal")
        })
        .collect::<Vec<_>>()
        .try_into()
        .expect("registered model SHA has 32 bytes");
    ImportRequest {
        strategy: TranscriptionStrategy::LegacyV1,
        job_id: Q03_JOB_ID,
        generation: Generation::first(),
        source_path: source.to_string_lossy().into_owned(),
        source_sha256: Some(crate::archive::sha256_file(&source).expect("hash synthetic source")),
        source_samples: Some(16_000),
        model_path: model.to_string_lossy().into_owned(),
        model_sha256,
        destination: root.join("archive").to_string_lossy().into_owned(),
        config: JobConfig {
            language: LanguageChoice::Automatic,
            compute: ComputeChoice::Auto,
        },
    }
}

fn synthetic_worker_root(root: &Path) -> PathBuf {
    let worker_root = root.join("synthetic-runtime/worker");
    fs::create_dir_all(&worker_root).expect("create synthetic worker directory");
    worker_root
}

fn synthetic_parakeet_paths(worker: PathBuf) -> crate::parakeet_import::ParakeetWorkerPaths {
    let runtime_root = worker
        .parent()
        .and_then(Path::parent)
        .expect("synthetic worker is beneath its runtime")
        .to_path_buf();
    let native_dir = runtime_root.join("native");
    let model = runtime_root.join("model.gguf");
    fs::create_dir_all(&native_dir).expect("create synthetic native directory");
    fs::write(&model, b"synthetic model path").expect("create synthetic model path");
    crate::parakeet_import::ParakeetWorkerPaths {
        executable: worker,
        native_dir,
        model,
        runtime_root,
    }
}

struct PipeHoldFiles {
    ready: PathBuf,
    release: PathBuf,
    finished: PathBuf,
}

struct PipeHoldRelease(PipeHoldFiles);

impl Drop for PipeHoldRelease {
    fn drop(&mut self) {
        let _ = fs::write(&self.0.release, b"release");
        let _ = wait_for_marker(&self.0.finished, Duration::from_secs(3));
    }
}

fn wait_for_marker(path: &Path, timeout: Duration) -> bool {
    let deadline = Instant::now() + timeout;
    while !path.is_file() && Instant::now() < deadline {
        thread::yield_now();
    }
    path.is_file()
}

fn wait_for_parakeet_exit(
    process: &mut crate::parakeet_import::ParakeetProcess,
    timeout: Duration,
) -> Option<std::process::ExitStatus> {
    let deadline = Instant::now() + timeout;
    while Instant::now() < deadline {
        match process.try_wait().expect("wait for fake worker exit") {
            Some(status) => return Some(status),
            None => thread::yield_now(),
        }
    }
    None
}

fn pipe_hold_files(root: &Path, name: &str) -> PipeHoldFiles {
    PipeHoldFiles {
        ready: root.join(format!("{name}-ready")),
        release: root.join(format!("{name}-release")),
        finished: root.join(format!("{name}-finished")),
    }
}

fn compile_pipe_holding_eof_worker(
    worker_root: &Path,
    name: &str,
    files: &PipeHoldFiles,
    exit_code: i32,
) -> PathBuf {
    let source = r###"
use std::{
    env,
    fs,
    path::Path,
    process::{Command, Stdio},
    thread,
    time::{Duration, Instant},
};
const READY: &str = __READY__;
const RELEASE: &str = __RELEASE__;
const FINISHED: &str = __FINISHED__;
const EXIT_CODE: i32 = __EXIT_CODE__;
fn wait_for(path: &str, timeout: Duration) -> bool {
    let deadline = Instant::now() + timeout;
    while !Path::new(path).is_file() && Instant::now() < deadline {
        thread::yield_now();
    }
    Path::new(path).is_file()
}
fn main() {
    if env::args().nth(1).as_deref() == Some("--hold-stdout") {
        fs::write(READY, b"ready").expect("signal pipe holder ready");
        let _ = wait_for(RELEASE, Duration::from_secs(12));
        fs::write(FINISHED, b"finished").expect("signal pipe holder finished");
        return;
    }
    let executable = env::current_exe().expect("worker executable path");
    let mut holder = Command::new(executable)
        .arg("--hold-stdout")
        .stdin(Stdio::null())
        .stdout(Stdio::inherit())
        .stderr(Stdio::null())
        .spawn()
        .expect("spawn stdout pipe holder");
    if !wait_for(READY, Duration::from_secs(8)) {
        let _ = holder.kill();
        std::process::exit(97);
    }
    drop(holder);
    std::process::exit(EXIT_CODE);
}
"###
    .replace(
        "__READY__",
        &serde_json::to_string(files.ready.to_string_lossy().as_ref()).unwrap(),
    )
    .replace(
        "__RELEASE__",
        &serde_json::to_string(files.release.to_string_lossy().as_ref()).unwrap(),
    )
    .replace(
        "__FINISHED__",
        &serde_json::to_string(files.finished.to_string_lossy().as_ref()).unwrap(),
    )
    .replace("__EXIT_CODE__", &exit_code.to_string());
    compile_worker(worker_root, name, &source)
}

fn compile_nominal_import_worker(
    worker_root: &Path,
    request: &ImportRequest,
    source_sha256: &str,
    acknowledge_stop: bool,
    pipe_hold: Option<&PipeHoldFiles>,
    shutdown_marker: Option<&Path>,
) -> PathBuf {
    let key = crate::archive::ArchiveQualificationKey::parakeet_cpu_test();
    let identity = serde_json::json!({
        "model_sha256": key.artifact_revision,
        "runtime_sha256": key.runtime_build,
        "build_sha256": key.worker_build,
        "profile": key.inference_profile,
    });
    let ready = serde_json::json!({
        "version": 1,
        "message": {
            "type": "ready",
            "identity": identity.clone(),
            "backend": "CPU",
            "native_version": "fixture",
        }
    });
    let result = serde_json::json!({
        "version": 1,
        "message": {
            "type": "result",
            "request_id": 1,
            "job_id": format!("{:032x}", request.job_id.0),
            "generation": request.generation.get(),
            "attempt": 0,
            "identity": identity,
            "source_sha256": source_sha256,
            "duration_samples": request.source_samples.expect("fixture duration"),
            "text": "hello.",
            "words": [{ "text": "hello.", "start_ms": 0, "end_ms": 500 }],
            "native_inference_ms": 0,
        }
    });
    let ready_literal = serde_json::to_string(&ready.to_string()).expect("encode READY frame");
    let result_literal = serde_json::to_string(&result.to_string()).expect("encode RESULT frame");
    let commands = worker_root.join("commands.jsonl");
    let commands_literal = serde_json::to_string(&commands.to_string_lossy().to_string())
        .expect("encode command trace path");
    let acknowledge_stop = acknowledge_stop.to_string();
    let hold_ready = pipe_hold.map_or_else(String::new, |files| {
        files.ready.to_string_lossy().into_owned()
    });
    let hold_release = pipe_hold.map_or_else(String::new, |files| {
        files.release.to_string_lossy().into_owned()
    });
    let hold_finished = pipe_hold.map_or_else(String::new, |files| {
        files.finished.to_string_lossy().into_owned()
    });
    let hold_ready_literal = serde_json::to_string(&hold_ready).expect("encode hold ready path");
    let hold_release_literal =
        serde_json::to_string(&hold_release).expect("encode hold release path");
    let hold_finished_literal =
        serde_json::to_string(&hold_finished).expect("encode hold finished path");
    let shutdown_marker =
        shutdown_marker.map_or_else(String::new, |path| path.to_string_lossy().into_owned());
    let shutdown_literal =
        serde_json::to_string(&shutdown_marker).expect("encode shutdown marker path");
    let source = r###"
use std::{env, fs::{self, OpenOptions}, io::{self, BufRead, Write}, path::Path, process::{Command, Stdio}, thread, time::{Duration, Instant}};
const READY: &str = __READY__;
const RESULT: &str = __RESULT__;
const COMMANDS: &str = __COMMANDS__;
const ACKNOWLEDGE_STOP: bool = __ACKNOWLEDGE_STOP__;
const HOLD_READY: &str = __HOLD_READY__;
const HOLD_RELEASE: &str = __HOLD_RELEASE__;
const HOLD_FINISHED: &str = __HOLD_FINISHED__;
const SHUTDOWN_MARKER: &str = __SHUTDOWN_MARKER__;
fn wait_for(path: &str, timeout: Duration) -> bool {
    let deadline = Instant::now() + timeout;
    while !Path::new(path).is_file() && Instant::now() < deadline { thread::yield_now(); }
    Path::new(path).is_file()
}
fn main() {
    if env::args().nth(1).as_deref() == Some("--hold-stdout") {
        fs::write(HOLD_READY, b"ready").expect("signal holder ready");
        let _ = wait_for(HOLD_RELEASE, Duration::from_secs(12));
        fs::write(HOLD_FINISHED, b"finished").expect("signal holder finished");
        return;
    }
    if !HOLD_READY.is_empty() {
        let executable = env::current_exe().expect("worker executable");
        let holder = Command::new(executable).arg("--hold-stdout")
            .stdin(Stdio::null()).stdout(Stdio::inherit()).stderr(Stdio::null())
            .spawn().expect("spawn stdout pipe holder");
        assert!(wait_for(HOLD_READY, Duration::from_secs(8)), "stdout holder ready");
        drop(holder);
    }
    println!("{READY}");
    let _ = io::stdout().flush();
    for line in io::stdin().lock().lines().flatten() {
        let mut file = OpenOptions::new().create(true).append(true).open(COMMANDS).expect("command trace");
        writeln!(file, "{line}").expect("record command");
        if line.contains("\"type\":\"transcribe\"") {
            println!("{RESULT}");
            let _ = io::stdout().flush();
        } else if line.contains("\"type\":\"shutdown\"") {
            if !SHUTDOWN_MARKER.is_empty() {
                fs::write(SHUTDOWN_MARKER, b"shutdown").expect("signal shutdown received");
            }
            if ACKNOWLEDGE_STOP {
                println!("{}", r#"{"version":1,"message":{"type":"stopped"}}"#);
                let _ = io::stdout().flush();
            }
            return;
        }
    }
}
"###
    .replace("__READY__", &ready_literal)
    .replace("__RESULT__", &result_literal)
    .replace("__COMMANDS__", &commands_literal)
    .replace("__ACKNOWLEDGE_STOP__", &acknowledge_stop)
    .replace("__HOLD_READY__", &hold_ready_literal)
    .replace("__HOLD_RELEASE__", &hold_release_literal)
    .replace("__HOLD_FINISHED__", &hold_finished_literal)
    .replace("__SHUTDOWN_MARKER__", &shutdown_literal);
    compile_worker(worker_root, "parakeet-nominal-import", &source)
}

fn poll_state_snapshot(runtime: &ImportRuntime) -> serde_json::Value {
    let active = runtime.active.as_ref();
    serde_json::json!({
        "active": active.map(|state| serde_json::json!({
            "job_id": format!("{:032x}", state.job_id.0),
            "generation": state.generation.get(),
            "instance_id": state.instance_id,
            "backend": format!("{:?}", state.backend),
            "attempt": state.attempt_number,
            "gpu_attested": state.gpu_attested,
        })),
        "process": runtime.parakeet.is_some(),
        "stopped_ack": runtime.parakeet_stopped_ack,
        "end": runtime.parakeet_end.map(|(job_id, generation, sequence, offset)| serde_json::json!([
            format!("{:032x}", job_id.0), generation.get(), sequence, offset
        ])),
        "queued_events": runtime.parakeet_events.iter().map(|event| format!("{event:?}")).collect::<Vec<_>>(),
        "vad": runtime.parakeet_vad.is_some(),
        "native_call_started": runtime.parakeet_native_call_started,
        "fallback_reason": runtime.auto_fallback_reason.as_deref(),
    })
}

fn record_poll_result(
    runtime: &mut ImportRuntime,
    trace: &mut Vec<serde_json::Value>,
    phase: &str,
) -> Option<Result<WorkerEvent, PortError>> {
    let before = poll_state_snapshot(runtime);
    let result = runtime.poll_parakeet_worker();
    let after = poll_state_snapshot(runtime);
    trace.push(serde_json::json!({
        "phase": phase,
        "before": before,
        "result": result.as_ref().map(|value| format!("{value:?}")),
        "after": after,
    }));
    result
}

fn poll_traced_until_event(
    runtime: &mut ImportRuntime,
    trace: &mut Vec<serde_json::Value>,
    helper_diagnostics: &mut Vec<serde_json::Value>,
    phase: &str,
) -> Result<WorkerEvent, PortError> {
    trace.push(serde_json::json!({
        "phase": format!("{phase}_wait_started"),
        "observation": "fixed_helper_boundary",
    }));
    let deadline = Instant::now() + Duration::from_secs(8);
    let mut unchanged_wait_polls = 0_u64;
    let mut previous = poll_state_snapshot(runtime);
    while Instant::now() < deadline {
        let before = poll_state_snapshot(runtime);
        let result = runtime.poll_parakeet_worker();
        let after = poll_state_snapshot(runtime);
        if let Some(result) = result {
            helper_diagnostics.push(serde_json::json!({
                "phase": phase,
                "polls_without_state_change": unchanged_wait_polls,
            }));
            trace.push(serde_json::json!({
                "phase": phase,
                "before": before,
                "result": format!("{result:?}"),
                "after": after,
            }));
            return result;
        }
        if before != after || previous != after {
            trace.push(serde_json::json!({
                "phase": format!("{phase}_no_event_transition"),
                "result": null,
                "before": before,
                "after": after,
            }));
            unchanged_wait_polls = 0;
        } else {
            unchanged_wait_polls = unchanged_wait_polls.saturating_add(1);
        }
        previous = after;
        thread::yield_now();
    }
    panic!("timed out polling {phase}");
}

fn trace_root_forms(root: &Path) -> Vec<String> {
    let root_text = root.to_string_lossy().into_owned();
    let forward_slashes = root_text.replace('\\', "/");
    let escaped = serde_json::to_string(&root_text).expect("encode escaped trace root");
    let escaped = escaped
        .strip_prefix('"')
        .and_then(|value| value.strip_suffix('"'))
        .expect("quoted JSON root");
    let escaped_forward =
        serde_json::to_string(&forward_slashes).expect("encode escaped forward-slash root");
    let escaped_forward = escaped_forward
        .strip_prefix('"')
        .and_then(|value| value.strip_suffix('"'))
        .expect("quoted JSON root");
    let mut forms = vec![
        root_text,
        forward_slashes,
        escaped.to_owned(),
        escaped_forward.to_owned(),
    ];
    for form in forms.clone() {
        let nested = serde_json::to_string(&form).expect("encode nested trace root");
        forms.push(
            nested
                .strip_prefix('"')
                .and_then(|value| value.strip_suffix('"'))
                .expect("quoted nested root")
                .to_owned(),
        );
    }
    forms
}

fn replace_trace_roots(value: &mut serde_json::Value, root: &Path) {
    let forms = trace_root_forms(root);
    match value {
        serde_json::Value::String(text) => {
            for root_text in &forms {
                *text = text.replace(root_text.as_str(), "<ROOT>");
            }
        }
        serde_json::Value::Array(values) => {
            for value in values {
                replace_trace_roots(value, root);
            }
        }
        serde_json::Value::Object(values) => {
            for value in values.values_mut() {
                replace_trace_roots(value, root);
            }
        }
        _ => {}
    }
}

fn assert_frozen_direct_trace(label: &str, stable: &[u8]) {
    let references: std::collections::BTreeMap<String, String> = serde_json::from_str(
        include_str!("../../../../../tests/fixtures/poll_parakeet_equivalence/direct-traces.json"),
    )
    .expect("decode frozen direct Parakeet poll traces");
    let expected = references
        .get(label)
        .unwrap_or_else(|| panic!("missing frozen direct poll trace {label}"));
    assert_eq!(
        stable,
        expected.as_bytes(),
        "direct Parakeet poll trace changed for {label}"
    );
}

fn write_poll_trace(
    root: &Path,
    label: &str,
    trace: &[serde_json::Value],
    helper_diagnostics: &[serde_json::Value],
) {
    let parent = root.parent().expect("test root has TEMP parent");
    let root_name = root.file_name().expect("test root name").to_string_lossy();
    let raw_path = parent.join(format!("poll-parakeet-{label}-{root_name}-raw.json"));
    let stable_path = parent.join(format!("poll-parakeet-{label}-{root_name}-stable.json"));
    let raw_value = serde_json::json!({
        "trace": trace,
        "helper_diagnostics": helper_diagnostics,
    });
    let raw = serde_json::to_vec_pretty(&raw_value).expect("serialize raw poll trace");
    let mut normalized = serde_json::Value::Array(trace.to_vec());
    replace_trace_roots(&mut normalized, root);
    let stable = serde_json::to_vec_pretty(&normalized).expect("serialize stable poll trace");
    let stable_text = String::from_utf8_lossy(&stable);
    for root_form in trace_root_forms(root) {
        assert!(
            !stable_text.contains(&root_form),
            "normalized trace retained temporary root spelling"
        );
    }
    if label != "Q03" {
        assert_frozen_direct_trace(label, &stable);
    }
    fs::write(&raw_path, raw).expect("persist raw poll trace in lot TEMP");
    fs::write(&stable_path, stable).expect("persist normalized poll trace in lot TEMP");
}

#[test]
fn poll_parakeet_cpu_import_records_nominal_commands_and_events() {
    let root = TestRoot::new("parakeet-cpu-import-nominal");
    let worker_root = synthetic_worker_root(&root.0);
    let model = root.0.join("model.gguf");
    fs::write(&model, b"synthetic model path").expect("create synthetic model file");
    let mut request = personal_import_request(&root.0, &model);
    request.config.compute = whisper_core::ComputeChoice::Cpu;
    let source_sha = request
        .source_sha256
        .as_ref()
        .map(|sha| {
            sha.iter()
                .map(|byte| format!("{byte:02x}"))
                .collect::<String>()
        })
        .expect("source hash");
    let worker =
        compile_nominal_import_worker(&worker_root, &request, &source_sha, true, None, None);
    let paths = synthetic_parakeet_paths(worker);
    let mut runtime = runtime_with_active_attempt(request.job_id);
    runtime.parakeet_paths = Some(paths.clone());
    runtime.active.as_mut().unwrap().import_request = Some(request.clone());
    runtime.parakeet = Some(
        crate::parakeet_import::ParakeetProcess::spawn_live(&paths, &root.0)
            .expect("spawn nominal CPU fixture worker"),
    );

    let mut trace = Vec::new();
    let mut helper_diagnostics = Vec::new();
    trace.push(serde_json::json!({
        "phase": "before_first_poll",
        "state": poll_state_snapshot(&runtime),
    }));
    let ready = poll_traced_until_event(&mut runtime, &mut trace, &mut helper_diagnostics, "ready");
    assert!(matches!(
        &ready,
        Ok(WorkerEvent::Ready { job_id, generation, instance_id: 7, backend: BackendKind::Cpu })
            if *job_id == request.job_id && *generation == request.generation
    ));

    let mut terminal = None;
    while terminal.is_none() {
        let event = poll_traced_until_event(
            &mut runtime,
            &mut trace,
            &mut helper_diagnostics,
            "next_import_event",
        );
        let is_terminal = matches!(&event, Ok(WorkerEvent::End { .. }) | Err(_));
        if is_terminal {
            terminal = Some(event);
        }
    }
    assert!(
        matches!(terminal, Some(Ok(WorkerEvent::End { job_id, generation, last_sequence: 1, last_offset: 16_000, .. })) if job_id == request.job_id && generation == request.generation)
    );
    let commands_path = worker_root.join("commands.jsonl");
    let command_lines = fs::read_to_string(commands_path).expect("worker command trace");
    assert!(command_lines.contains("\"type\":\"transcribe\""));
    assert!(command_lines.contains("\"type\":\"shutdown\""));
    trace.push(serde_json::json!({
        "phase": "ipc_commands",
        "commands": command_lines.lines().collect::<Vec<_>>(),
    }));
    write_poll_trace(&root.0, "Q01", &trace, &helper_diagnostics);
}

#[test]
fn poll_parakeet_eof_after_result_preserves_unacknowledged_end_behavior() {
    let root = TestRoot::new("parakeet-eof-after-result");
    let worker_root = synthetic_worker_root(&root.0);
    let model = root.0.join("model.gguf");
    fs::write(&model, b"synthetic model path").expect("create synthetic model file");
    let mut request = personal_import_request(&root.0, &model);
    request.config.compute = whisper_core::ComputeChoice::Cpu;
    let source_sha = request
        .source_sha256
        .as_ref()
        .map(|sha| {
            sha.iter()
                .map(|byte| format!("{byte:02x}"))
                .collect::<String>()
        })
        .expect("source hash");
    let hold_files = pipe_hold_files(&root.0, "parakeet-eof-after-result");
    let release = PipeHoldRelease(PipeHoldFiles {
        ready: hold_files.ready.clone(),
        release: hold_files.release.clone(),
        finished: hold_files.finished.clone(),
    });
    let shutdown_marker = root.0.join("parakeet-shutdown-received");
    let worker = compile_nominal_import_worker(
        &worker_root,
        &request,
        &source_sha,
        false,
        Some(&hold_files),
        Some(&shutdown_marker),
    );
    let paths = synthetic_parakeet_paths(worker);
    let mut runtime = runtime_with_active_attempt(request.job_id);
    runtime.parakeet_paths = Some(paths.clone());
    runtime.active.as_mut().unwrap().import_request = Some(request.clone());
    runtime.parakeet = Some(
        crate::parakeet_import::ParakeetProcess::spawn_live(&paths, &root.0)
            .expect("spawn result-then-EOF worker"),
    );
    let mut trace = vec![serde_json::json!({
        "phase": "started",
        "state": poll_state_snapshot(&runtime),
    })];
    let mut helper_diagnostics = Vec::new();

    assert!(matches!(
        poll_traced_until_event(&mut runtime, &mut trace, &mut helper_diagnostics, "ready"),
        Ok(WorkerEvent::Ready { .. })
    ));
    assert!(matches!(
        poll_traced_until_event(
            &mut runtime,
            &mut trace,
            &mut helper_diagnostics,
            "result_progress"
        ),
        Ok(WorkerEvent::Progress {
            completed_samples: 16_000,
            total_samples: 16_000,
            ..
        })
    ));
    assert!(matches!(
        poll_traced_until_event(
            &mut runtime,
            &mut trace,
            &mut helper_diagnostics,
            "result_segment"
        ),
        Ok(WorkerEvent::Segment(_))
    ));
    assert!(wait_for_marker(&shutdown_marker, Duration::from_secs(8)));
    let status = wait_for_parakeet_exit(runtime.parakeet.as_mut().unwrap(), Duration::from_secs(8));
    let exit_success = status.as_ref().is_some_and(|status| status.success());
    assert!(exit_success);
    trace.push(serde_json::json!({
        "phase": "shutdown_received_and_parent_exited",
        "success": exit_success,
    }));
    let eof =
        record_poll_result(&mut runtime, &mut trace, "eof_after_result").expect("EOF after result");
    drop(release);
    trace.push(serde_json::json!({
        "phase": "holder_released",
        "holder_finished": hold_files.finished.is_file(),
    }));
    assert!(
        matches!(
            &eof,
            Err(PortError::Failed(message))
                if message == "WorkerExited: process ended before result acknowledgement"
        ),
        "unexpected Q06 EOF result: {eof:?}"
    );
    assert!(runtime.parakeet.is_none());
    assert!(runtime.parakeet_end.is_none());
    assert_eq!(
        fs::read_to_string(worker_root.join("commands.jsonl"))
            .expect("record commands through EOF")
            .lines()
            .count(),
        2,
        "Transcribe and Shutdown are sent before EOF is observed"
    );
    let commands =
        fs::read_to_string(worker_root.join("commands.jsonl")).expect("commands sent through EOF");
    trace.push(serde_json::json!({
        "phase": "ipc_commands",
        "commands": commands.lines().collect::<Vec<_>>(),
    }));
    write_poll_trace(&root.0, "Q06", &trace, &helper_diagnostics);
}

#[test]
fn poll_parakeet_failed_message_from_older_attempt_is_terminal() {
    let root = TestRoot::new("parakeet-older-attempt-failed");
    let worker_root = synthetic_worker_root(&root.0);
    let model = root.0.join("model.gguf");
    fs::write(&model, b"synthetic model path").expect("create synthetic model file");
    let request = personal_import_request(&root.0, &model);
    let stale_failure = serde_json::json!({
        "version": 1,
        "message": {
            "type": "failed",
            "request_id": 1,
            "job_id": format!("{:032x}", request.job_id.0),
            "generation": request.generation.get(),
            "attempt": 0,
            "identity": null,
            "code": "BackendUnavailable",
            "message": "synthetic failure from previous attempt",
        }
    });
    let stale_literal =
        serde_json::to_string(&stale_failure.to_string()).expect("encode previous-attempt failure");
    let source = r###"
use std::io::{self, BufRead, Write};
const FAILED: &str = __FAILED__;
fn main() {
    println!("{FAILED}");
    let _ = io::stdout().flush();
    for line in io::stdin().lock().lines().flatten() {
        if line.contains("\"type\":\"shutdown\"") { return; }
    }
}
"###
    .replace("__FAILED__", &stale_literal);
    let worker = compile_worker(&worker_root, "parakeet-older-attempt", &source);
    let paths = synthetic_parakeet_paths(worker);
    let mut runtime = runtime_with_active_attempt(request.job_id);
    let active = runtime.active.as_mut().unwrap();
    active.backend = BackendKind::Cuda;
    active.attempt_number = 1;
    active.import_request = Some(request);
    runtime.parakeet = Some(
        crate::parakeet_import::ParakeetProcess::spawn_live(&paths, &root.0)
            .expect("spawn old-attempt worker"),
    );

    let mut trace = vec![serde_json::json!({
        "phase": "active_attempt_one",
        "state": poll_state_snapshot(&runtime),
    })];
    let mut helper_diagnostics = Vec::new();
    let failure = poll_traced_until_event(
        &mut runtime,
        &mut trace,
        &mut helper_diagnostics,
        "old_attempt_failed",
    );
    assert!(matches!(
        failure,
        Ok(WorkerEvent::Failed {
            code: whisper_core::ipc::WorkerErrorCode::Internal,
            message,
            ..
        }) if message == "BackendUnavailable: synthetic failure from previous attempt"
    ));
    assert!(runtime.parakeet.is_none());
    assert!(runtime.active.is_some());
    assert!(runtime.auto_fallback_reason.is_none());
    write_poll_trace(&root.0, "Q07", &trace, &helper_diagnostics);
}

#[test]
fn poll_parakeet_stopped_ack_preserves_wait_and_maps_all_exit_states() {
    let root = TestRoot::new("parakeet-stopped-ack");
    let worker_root = synthetic_worker_root(&root.0);
    let job_id = JobId(73_240);
    let generation = Generation::first();
    let mut trace = Vec::new();
    let mut helper_diagnostics = Vec::new();

    let waiting_worker = compile_worker(
        &worker_root,
        "parakeet-waiting-worker",
        "fn main() { std::thread::park(); }",
    );
    let waiting_paths = synthetic_parakeet_paths(waiting_worker);
    let mut waiting = runtime_with_active_attempt(job_id);
    waiting.parakeet = Some(
        crate::parakeet_import::ParakeetProcess::spawn_live(&waiting_paths, &root.0)
            .expect("spawn waiting fake worker"),
    );
    waiting.parakeet_stopped_ack = true;
    waiting.parakeet_end = Some((job_id, generation, 2, 320));
    assert!(record_poll_result(&mut waiting, &mut trace, "stopped_ack_wait").is_none());
    assert!(waiting.parakeet.is_some());
    assert!(waiting.parakeet_stopped_ack);
    assert_eq!(waiting.parakeet_end, Some((job_id, generation, 2, 320)));
    waiting.parakeet.as_mut().unwrap().terminate().unwrap();

    let success_worker = compile_worker(&worker_root, "parakeet-success-worker", "fn main() {}");
    let success_paths = synthetic_parakeet_paths(success_worker);
    let mut success = runtime_with_active_attempt(job_id);
    success.parakeet = Some(
        crate::parakeet_import::ParakeetProcess::spawn_live(&success_paths, &root.0)
            .expect("spawn successful fake worker"),
    );
    success.parakeet_stopped_ack = true;
    success.parakeet_end = Some((job_id, generation, 2, 320));
    assert!(matches!(
        poll_traced_until_event(
            &mut success,
            &mut trace,
            &mut helper_diagnostics,
            "stopped_ack_success"
        ),
        Ok(WorkerEvent::End {
            job_id: actual_job,
            generation: actual_generation,
            instance_id: 7,
            last_sequence: 2,
            last_offset: 320,
        }) if actual_job == job_id && actual_generation == generation
    ));
    assert!(success.parakeet.is_none());
    assert!(!success.parakeet_stopped_ack);
    assert!(success.parakeet_end.is_none());

    let no_end_worker = compile_worker(&worker_root, "parakeet-no-end-worker", "fn main() {}");
    let no_end_paths = synthetic_parakeet_paths(no_end_worker);
    let mut no_end = runtime_with_active_attempt(job_id);
    no_end.parakeet = Some(
        crate::parakeet_import::ParakeetProcess::spawn_live(&no_end_paths, &root.0)
            .expect("spawn no-result fake worker"),
    );
    no_end.parakeet_stopped_ack = true;
    assert!(matches!(
        poll_traced_until_event(
            &mut no_end,
            &mut trace,
            &mut helper_diagnostics,
            "stopped_ack_without_end"
        ),
        Err(PortError::Failed(message))
            if message == "WorkerExited: Parakeet stopped without a transcription result"
    ));
    assert!(no_end.parakeet.is_none());
    assert!(!no_end.parakeet_stopped_ack);

    let failed_worker = compile_worker(
        &worker_root,
        "parakeet-failed-worker",
        "fn main() { std::process::exit(9); }",
    );
    let failed_paths = synthetic_parakeet_paths(failed_worker);
    let mut failed = runtime_with_active_attempt(job_id);
    failed.parakeet = Some(
        crate::parakeet_import::ParakeetProcess::spawn_live(&failed_paths, &root.0)
            .expect("spawn failing fake worker"),
    );
    failed.parakeet_stopped_ack = true;
    failed.parakeet_end = Some((job_id, generation, 2, 320));
    assert!(matches!(
        poll_traced_until_event(
            &mut failed,
            &mut trace,
            &mut helper_diagnostics,
            "stopped_ack_failure"
        ),
        Err(PortError::Failed(message)) if message.starts_with("WorkerExited:")
    ));
    assert!(failed.parakeet.is_none());
    assert!(!failed.parakeet_stopped_ack);
    assert!(failed.parakeet_end.is_none());
    write_poll_trace(&root.0, "P03", &trace, &helper_diagnostics);
}

#[test]
fn poll_parakeet_eof_status_preserves_the_existing_end_asymmetry() {
    let root = TestRoot::new("parakeet-eof-status");
    let worker_root = synthetic_worker_root(&root.0);
    let job_id = JobId(73_241);
    let generation = Generation::first();
    let mut trace = Vec::new();
    let success_files = pipe_hold_files(&root.0, "parakeet-eof-success");
    let success_release = PipeHoldRelease(PipeHoldFiles {
        ready: success_files.ready.clone(),
        release: success_files.release.clone(),
        finished: success_files.finished.clone(),
    });
    let success_worker =
        compile_pipe_holding_eof_worker(&worker_root, "parakeet-eof-success", &success_files, 0);
    let success_paths = synthetic_parakeet_paths(success_worker);
    let mut success = runtime_with_active_attempt(job_id);
    success.parakeet = Some(
        crate::parakeet_import::ParakeetProcess::spawn_live(&success_paths, &root.0)
            .expect("spawn successful EOF worker"),
    );
    success.parakeet_end = Some((job_id, generation, 1, 160));
    assert!(wait_for_marker(
        &success_files.ready,
        Duration::from_secs(8)
    ));
    let success_status =
        wait_for_parakeet_exit(success.parakeet.as_mut().unwrap(), Duration::from_secs(8));
    let success_exited = success_status
        .as_ref()
        .is_some_and(|status| status.success());
    assert!(success_exited);
    trace.push(serde_json::json!({
        "phase": "success_parent_exited_holder_open",
        "status_success": success_exited,
    }));
    let success_result = record_poll_result(&mut success, &mut trace, "success_empty_channel_exit");
    drop(success_release);
    trace.push(serde_json::json!({
        "phase": "success_holder_released",
        "finished": success_files.finished.is_file(),
    }));
    assert!(
        matches!(
            &success_result,
            Some(Err(PortError::Failed(message)))
                if message == "WorkerExited: process ended before result acknowledgement"
        ),
        "unexpected P04 successful-worker poll result: {success_result:?}"
    );
    assert!(success.parakeet.is_none());
    assert!(success.parakeet_end.is_none());

    let failed_files = pipe_hold_files(&root.0, "parakeet-eof-failed");
    let failed_release = PipeHoldRelease(PipeHoldFiles {
        ready: failed_files.ready.clone(),
        release: failed_files.release.clone(),
        finished: failed_files.finished.clone(),
    });
    let failed_worker =
        compile_pipe_holding_eof_worker(&worker_root, "parakeet-eof-failed", &failed_files, 9);
    let failed_paths = synthetic_parakeet_paths(failed_worker);
    let mut failed = runtime_with_active_attempt(job_id);
    failed.parakeet = Some(
        crate::parakeet_import::ParakeetProcess::spawn_live(&failed_paths, &root.0)
            .expect("spawn failed EOF worker"),
    );
    failed.parakeet_end = Some((job_id, generation, 1, 160));
    assert!(wait_for_marker(&failed_files.ready, Duration::from_secs(8)));
    let failed_status =
        wait_for_parakeet_exit(failed.parakeet.as_mut().unwrap(), Duration::from_secs(8));
    let failed_exit_code = failed_status.as_ref().and_then(|status| status.code());
    assert_eq!(failed_exit_code, Some(9));
    trace.push(serde_json::json!({
        "phase": "failed_parent_exited_holder_open",
        "exit_code": failed_exit_code,
    }));
    let failed_result = record_poll_result(&mut failed, &mut trace, "failed_empty_channel_exit");
    drop(failed_release);
    trace.push(serde_json::json!({
        "phase": "failed_holder_released",
        "finished": failed_files.finished.is_file(),
    }));
    assert!(matches!(
        failed_result,
        Some(Err(PortError::Failed(message))) if message.starts_with("WorkerExited:")
    ));
    assert!(failed.parakeet.is_none());
    assert_eq!(failed.parakeet_end, Some((job_id, generation, 1, 160)));
    write_poll_trace(&root.0, "P04", &trace, &[]);
}

#[test]
fn poll_parakeet_ready_without_active_import_is_stale() {
    let root = TestRoot::new("parakeet-ready-stale");
    let worker_root = synthetic_worker_root(&root.0);
    let ready_worker = compile_worker(
        &worker_root,
        "parakeet-ready-stale-worker",
        r###"fn main() { println!("{}", r#"{"version":1,"message":{"type":"ready","identity":{"model_sha256":"fixture","runtime_sha256":"fixture","build_sha256":"fixture","profile":"import-single-pass"},"backend":"CPU","native_version":"fixture"}}"#); }"###,
    );
    let paths = synthetic_parakeet_paths(ready_worker);
    let mut runtime = runtime_with_active_attempt(JobId(73_242));
    runtime.active = None;
    runtime.parakeet = Some(
        crate::parakeet_import::ParakeetProcess::spawn_live(&paths, &root.0)
            .expect("spawn READY worker"),
    );

    let mut trace = Vec::new();
    let mut helper_diagnostics = Vec::new();
    assert!(matches!(
        poll_traced_until_event(
            &mut runtime,
            &mut trace,
            &mut helper_diagnostics,
            "ready_without_active"
        ),
        Err(PortError::Failed(message))
            if message == "StaleResponse: Parakeet Ready without an active import"
    ));
    write_poll_trace(&root.0, "P06", &trace, &helper_diagnostics);
}

#[test]
#[cfg(feature = "personal-qualification")]
fn poll_parakeet_gpu_failure_falls_back_to_qualified_cpu_fixture() {
    if let Some(root) = std::env::var_os(CHILD_ROOT) {
        run_personal_cpu_fallback_child(Path::new(&root));
        return;
    }

    let root = TestRoot::new("parakeet-equivalence-child");
    let model = std::env::var_os("N1_TEST_PERSONAL_PARAKEET_MODEL")
        .map(PathBuf::from)
        .expect("guard supplies the validated Personal Parakeet model");
    let local_app_data = root.0.join("isolated-localappdata");
    let runtime_root = local_app_data.join("Whisper");
    let output = Command::new(std::env::current_exe().expect("test executable path"))
        .arg("--exact")
        .arg("worker_ipc::runtime::poll::tests::parakeet_equivalence::poll_parakeet_gpu_failure_falls_back_to_qualified_cpu_fixture")
        .arg("--nocapture")
        .env(CHILD_ROOT, &root.0)
        .env("LOCALAPPDATA", &local_app_data)
        .env("PARAKEET_L2_RUNTIME_ROOT", &runtime_root)
        .env(
            "PARAKEET_L2_MODEL",
            runtime_root.join("models/parakeet-tdt-0.6b-v3.q8_0.gguf"),
        )
        .env(
            "PARAKEET_L2_CPU_WORKER",
            runtime_root.join("worker/whisper-worker-parakeet-cpu.exe"),
        )
        .env("PARAKEET_L2_CPU_NATIVE_DIR", runtime_root.join("native/cpu"))
        .env("N1_TEST_PERSONAL_PARAKEET_MODEL", model)
        .output()
        .expect("run isolated Parakeet fallback child");
    assert!(
        output.status.success(),
        "Q03 child failed:\n{}\n{}",
        String::from_utf8_lossy(&output.stdout),
        String::from_utf8_lossy(&output.stderr)
    );
    assert!(
        String::from_utf8_lossy(&output.stdout).contains("1 passed; 0 failed"),
        "Q03 child did not execute exactly one test:\n{}",
        String::from_utf8_lossy(&output.stdout)
    );
}

#[cfg(feature = "personal-qualification")]
fn run_personal_cpu_fallback_child(root: &Path) {
    let model_source = PathBuf::from(
        std::env::var_os("N1_TEST_PERSONAL_PARAKEET_MODEL")
            .expect("guard supplies the validated Personal Parakeet model"),
    );
    let install_root = model_source
        .parent()
        .and_then(Path::parent)
        .expect("model lives under the personal Whisper installation");
    let local_app_data = root.join("isolated-localappdata");
    let runtime_root = local_app_data.join("Whisper");
    let worker_dir = runtime_root.join("worker");
    let cpu_native = runtime_root.join("native/cpu");
    let gpu_native = runtime_root.join("native/gpu");
    let model_path = runtime_root.join("models/parakeet-tdt-0.6b-v3.q8_0.gguf");
    fs::create_dir_all(&worker_dir).expect("create isolated worker directory");
    fs::create_dir_all(&cpu_native).expect("create isolated CPU runtime directory");
    fs::create_dir_all(&gpu_native).expect("create isolated GPU runtime directory");
    fs::create_dir_all(model_path.parent().expect("model parent"))
        .expect("create isolated model directory");
    fs::copy(&model_source, &model_path).expect("copy verified model into isolated fixture");
    for name in [
        "nemo_speech_asr_c.dll",
        "nemo_speech_asr.dll",
        "ggml.dll",
        "ggml-base.dll",
        "ggml-cpu.dll",
    ] {
        fs::copy(
            install_root.join("native/cpu").join(name),
            cpu_native.join(name),
        )
        .expect("copy CPU runtime DLL as read-only qualification data");
    }

    let ready_identity = worker_dir.join("cpu-ready-identity.json");
    let transcribe_marker = worker_dir.join("cpu-transcribe.jsonl");
    let cpu_source = r###"
use std::{env, fs::OpenOptions, io::{self, BufRead, Write}};
fn main() {
    let worker_dir = env::current_exe().expect("worker path").parent().expect("worker dir").to_path_buf();
    let ready = std::fs::read_to_string(worker_dir.join("cpu-ready-identity.json")).expect("fixture identity");
    let mut frame = String::from(r#"{"version":1,"message":{"type":"ready","identity":{"#);
    frame.push_str(&ready);
    frame.push_str(r#"},"backend":"CPU","native_version":"fixture"}}"#);
    println!("{frame}");
    let _ = io::stdout().flush();
    for line in io::stdin().lock().lines().flatten() {
        let mut commands = OpenOptions::new().create(true).append(true).open(worker_dir.join("cpu-commands.jsonl")).expect("command trace");
        writeln!(commands, "{line}").expect("record CPU command");
        if line.contains("\"type\":\"transcribe\"") {
            let marker = worker_dir.join("cpu-transcribe.jsonl");
            let mut file = OpenOptions::new().create(true).append(true).open(marker).expect("marker");
            writeln!(file, "{line}").expect("record CPU transcribe");
        }
        if line.contains("\"type\":\"shutdown\"") { break; }
    }
}
"###;
    let cpu_worker = compile_worker_relative(
        &worker_dir,
        "whisper_worker_parakeet_cpu",
        "whisper-worker-parakeet-cpu.rs",
        "whisper-worker-parakeet-cpu.exe",
        cpu_source,
    );
    let cpu_worker_sha256 = crate::archive::sha256_file(&cpu_worker)
        .expect("hash deterministic CPU worker fixture")
        .iter()
        .map(|byte| format!("{byte:02x}"))
        .collect::<String>();
    fs::write(worker_dir.join("gpu-commands.jsonl"), b"")
        .expect("record that GPU received no IPC command before termination");
    let cpu_paths = crate::parakeet_import::ParakeetWorkerPaths {
        executable: cpu_worker,
        native_dir: cpu_native,
        model: model_path.clone(),
        runtime_root: runtime_root.clone(),
    };
    let key = cpu_paths
        .qualification_key(whisper_core::parakeet_ipc::PARAKEET_PROFILE_IMPORT_SINGLE_PASS)
        .expect("dynamic isolated personal CPU qualification key");
    assert_eq!(key.worker_build, cpu_worker_sha256);
    let identity = format!(
        r#""model_sha256":"{}","runtime_sha256":"{}","build_sha256":"{}","profile":"{}""#,
        key.artifact_revision, key.runtime_build, key.worker_build, key.inference_profile
    );
    fs::write(&ready_identity, identity).expect("write dynamic CPU READY identity");

    let gpu_worker_source = r###"
use std::{env, fs::OpenOptions, io::{self, BufRead, Write}};
fn main() {
    let directory = env::current_exe().expect("worker path").parent().expect("worker directory").to_path_buf();
    let event = r#"{"version":1,"message":{"type":"failed","request_id":1,"job_id":"__JOB_ID__","generation":1,"attempt":1,"identity":null,"code":"BackendUnavailable","message":"synthetic pre-audio GPU failure"}}"#;
    let mut events = OpenOptions::new().create(true).append(true).open(directory.join("gpu-events.jsonl")).expect("event trace");
    writeln!(events, "{event}").expect("record GPU Failed");
    println!("{event}");
    let _ = io::stdout().flush();
    for line in io::stdin().lock().lines().flatten() {
        let mut commands = OpenOptions::new().create(true).append(true).open(directory.join("gpu-commands.jsonl")).expect("command trace");
        writeln!(commands, "{line}").expect("record GPU command");
        if line.contains("\"type\":\"shutdown\"") { break; }
    }
}
"###;
    let gpu_worker_source =
        gpu_worker_source.replace("__JOB_ID__", &format!("{:032x}", Q03_JOB_ID.0));
    let gpu_worker = compile_worker_relative(
        &worker_dir,
        "whisper_worker_parakeet_gpu",
        "whisper-worker-parakeet-gpu.rs",
        "whisper-worker-parakeet-gpu.exe",
        &gpu_worker_source,
    );
    let gpu_paths = crate::parakeet_import::ParakeetWorkerPaths {
        executable: gpu_worker,
        native_dir: gpu_native,
        model: model_path.clone(),
        runtime_root: runtime_root.clone(),
    };
    let model_record =
        whisper_core::model_registry::model(whisper_core::model_catalog::ModelId::ParakeetTdt06BV3);
    assert_eq!(
        crate::model_catalog::cached_model_sha256(&model_path)
            .expect("verify copied model")
            .1
            .iter()
            .map(|byte| format!("{byte:02x}"))
            .collect::<String>(),
        model_record.artifact.sha256
    );

    let request = personal_import_request(root, &model_path);
    let mut runtime = runtime_with_active_attempt(request.job_id);
    runtime.archive = crate::archive::ArchiveStore::new(&request.destination);
    runtime
        .archive
        .prepare_with_qualification(
            request.clone(),
            None,
            Some(crate::archive::ArchiveQualificationKey::parakeet_gpu_test()),
        )
        .expect("prepare replaceable GPU pending import");
    runtime.parakeet_paths = Some(cpu_paths);
    runtime.parakeet = Some(
        crate::parakeet_import::ParakeetProcess::spawn(&gpu_paths)
            .expect("spawn synthetic GPU worker"),
    );
    runtime.active = Some(crate::worker_ipc::runtime::ImportRequestState {
        job_id: request.job_id,
        generation: request.generation,
        instance_id: 7,
        backend: BackendKind::Cuda,
        attempt_number: 1,
        import_request: Some(request.clone()),
        recovery: crate::worker_ipc::runtime::LiveRecoveryState::None,
        startup_ready: false,
        gpu_candidate: None,
        gpu_attested: false,
    });

    let mut trace = vec![serde_json::json!({
        "phase": "gpu_started",
        "state": poll_state_snapshot(&runtime),
    })];
    trace.push(serde_json::json!({
        "phase": "gpu_fallback_wait_started",
        "observation": "fixed_helper_boundary",
    }));
    let mut helper_diagnostics = Vec::new();
    let deadline = Instant::now() + Duration::from_secs(8);
    let mut fallback_completed = false;
    let mut unchanged_wait_polls = 0_u64;
    while Instant::now() < deadline && !fallback_completed {
        let before = poll_state_snapshot(&runtime);
        let result = runtime.poll_parakeet_worker();
        let after = poll_state_snapshot(&runtime);
        match result {
            Some(Err(error)) => panic!("GPU Failed or CPU fallback failed: {error:?}"),
            Some(Ok(event)) => panic!("unexpected event before CPU READY: {event:?}"),
            None if runtime
                .active
                .as_ref()
                .is_some_and(|active| active.backend == BackendKind::Cpu) =>
            {
                trace.push(serde_json::json!({
                    "phase": "gpu_failed_cpu_fallback_started",
                    "before": before,
                    "state": after,
                    "fallback_reason": runtime.auto_fallback_reason.as_deref(),
                }));
                fallback_completed = true;
            }
            None => {
                if before != after {
                    trace.push(serde_json::json!({
                        "phase": "fallback_poll_state_transition",
                        "result": null,
                        "before": before,
                        "state": after,
                    }));
                    unchanged_wait_polls = 0;
                } else {
                    unchanged_wait_polls = unchanged_wait_polls.saturating_add(1);
                }
                thread::yield_now();
            }
        }
    }
    helper_diagnostics.push(serde_json::json!({
        "phase": "gpu_fallback_wait",
        "polls_without_state_change": unchanged_wait_polls,
    }));
    assert!(fallback_completed, "GPU failure must start the CPU attempt");
    assert_eq!(
        runtime.active.as_ref().expect("CPU attempt").backend,
        BackendKind::Cpu
    );
    assert_eq!(
        runtime.active.as_ref().expect("CPU attempt").attempt_number,
        1
    );
    assert!(
        runtime
            .auto_fallback_reason
            .as_deref()
            .is_some_and(|reason| reason.contains("GPU worker failed before native inference"))
    );

    let cpu_ready = poll_traced_until_event(
        &mut runtime,
        &mut trace,
        &mut helper_diagnostics,
        "cpu_ready",
    );
    assert!(matches!(
        cpu_ready,
        Ok(WorkerEvent::Ready {
            job_id,
            generation,
            backend: BackendKind::Cpu,
            ..
        }) if job_id == request.job_id && generation == request.generation
    ));
    let marker_deadline = Instant::now() + Duration::from_secs(3);
    while Instant::now() < marker_deadline && !transcribe_marker.is_file() {
        thread::yield_now();
    }
    let transcribe = fs::read_to_string(&transcribe_marker).expect("CPU Transcribe wire marker");
    assert_eq!(transcribe.lines().count(), 1, "exactly one CPU Transcribe");
    assert!(transcribe.contains(&format!("\"job_id\":\"{:032x}\"", request.job_id.0)));
    assert!(
        !runtime.parakeet_native_call_started,
        "fixture never enters native inference"
    );
    assert!(runtime.auto_fallback_reason.is_some());
    let pending_path = Path::new(&request.destination)
        .join("transcriptions")
        .join(format!("{:032x}", request.job_id.0))
        .join(request.generation.get().to_string())
        .join("pending.json");
    let pending: serde_json::Value =
        serde_json::from_slice(&fs::read(pending_path).expect("read persisted pending record"))
            .expect("decode persisted pending record");
    let cpu_key = runtime
        .parakeet_paths
        .as_ref()
        .expect("CPU paths")
        .qualification_key(whisper_core::parakeet_ipc::PARAKEET_PROFILE_IMPORT_SINGLE_PASS)
        .expect("CPU qualification key");
    assert_eq!(
        pending["qualification"],
        serde_json::to_value(&cpu_key).expect("serialize CPU key")
    );
    trace.push(serde_json::json!({
        "phase": "cpu_transcribe_and_persisted_qualification",
        "transcribe_commands": transcribe.lines().collect::<Vec<_>>(),
        "pending": pending,
        "cpu_worker_build_sha256": cpu_worker_sha256,
        "cpu_state": poll_state_snapshot(&runtime),
    }));
    for (name, path) in [
        ("gpu_events", worker_dir.join("gpu-events.jsonl")),
        ("gpu_commands", worker_dir.join("gpu-commands.jsonl")),
        ("cpu_commands", worker_dir.join("cpu-commands.jsonl")),
    ] {
        let contents = fs::read_to_string(path).expect("read complete worker trace file");
        trace.push(serde_json::json!({
            "phase": name,
            "lines": contents.lines().map(str::to_owned).collect::<Vec<_>>(),
        }));
    }
    drop(runtime);
    write_poll_trace(root, "Q03", &trace, &helper_diagnostics);
}
