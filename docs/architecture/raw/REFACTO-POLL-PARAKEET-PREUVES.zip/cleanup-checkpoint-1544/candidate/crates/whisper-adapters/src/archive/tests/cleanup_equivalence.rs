use super::super::*;
use super::*;
use std::collections::HashMap;

fn cleanup_relative(root: &Path, path: &Path) -> String {
    path.strip_prefix(root)
        .unwrap()
        .to_string_lossy()
        .into_owned()
}

fn cleanup_normalization_roots(root: &Path) -> [String; 2] {
    [
        root.to_string_lossy().into_owned(),
        root.canonicalize().unwrap().to_string_lossy().into_owned(),
    ]
}

fn normalize_cleanup_json(root: &Path, value: &mut serde_json::Value) {
    fn normalize(
        value: &mut serde_json::Value,
        roots: &[String],
        identities: &mut HashMap<(u64, Vec<u8>, bool), u64>,
        volumes: &mut HashMap<u64, u64>,
    ) {
        match value {
            serde_json::Value::Object(object) => {
                if let (Some(volume), Some(file_id), Some(directory)) = (
                    object
                        .get("volume_serial")
                        .and_then(serde_json::Value::as_u64),
                    object.get("file_id").and_then(serde_json::Value::as_array),
                    object
                        .get("is_directory")
                        .and_then(serde_json::Value::as_bool),
                ) {
                    let bytes = file_id
                        .iter()
                        .filter_map(serde_json::Value::as_u64)
                        .map(|byte| byte as u8)
                        .collect::<Vec<_>>();
                    let next = identities.len() as u64 + 1;
                    let normalized = *identities.entry((volume, bytes, directory)).or_insert(next);
                    let volume_next = volumes.len() as u64 + 1;
                    let normalized_volume = *volumes.entry(volume).or_insert(volume_next);
                    let mut normalized_file_id = [0_u8; 16];
                    normalized_file_id[..8].copy_from_slice(&normalized.to_le_bytes());
                    object.insert("volume_serial".into(), serde_json::json!(normalized_volume));
                    object.insert(
                        "file_id".into(),
                        serde_json::to_value(normalized_file_id).unwrap(),
                    );
                }
                for child in object.values_mut() {
                    normalize(child, roots, identities, volumes);
                }
            }
            serde_json::Value::Array(array) => {
                for child in array {
                    normalize(child, roots, identities, volumes);
                }
            }
            serde_json::Value::String(text) => {
                for root in roots {
                    *text = text.replace(root, "<ROOT>");
                }
            }
            _ => {}
        }
    }

    normalize(
        value,
        &cleanup_normalization_roots(root),
        &mut HashMap::new(),
        &mut HashMap::new(),
    );
}

fn cleanup_tree_snapshot(root: &Path) -> Vec<serde_json::Value> {
    fn visit(root: &Path, directory: &Path, output: &mut Vec<serde_json::Value>) {
        for entry in fs::read_dir(directory).unwrap() {
            let entry = entry.unwrap();
            let path = entry.path();
            let metadata = entry.metadata().unwrap();
            let bytes = if !metadata.is_file() {
                None
            } else if path.extension().and_then(|value| value.to_str()) == Some("json") {
                let mut value: serde_json::Value =
                    serde_json::from_slice(&fs::read(&path).unwrap()).unwrap();
                normalize_cleanup_json(root, &mut value);
                Some(serde_json::to_vec(&value).unwrap().len() as u64)
            } else {
                Some(metadata.len())
            };
            output.push(serde_json::json!({
                "path": cleanup_relative(root, &path),
                "kind": if metadata.is_dir() { "directory" } else { "file" },
                "bytes": bytes,
                "sha256": if metadata.is_file()
                    && path.extension().and_then(|value| value.to_str()) != Some("json")
                {
                    Some(hex(&sha256_file(&path).unwrap()))
                } else {
                    None
                },
            }));
            if metadata.is_dir() {
                visit(root, &path, output);
            }
        }
    }

    let mut entries = Vec::new();
    visit(root, root, &mut entries);
    entries
}

fn stable_cleanup_plan(root: &Path, plan: &CleanupPlan) -> serde_json::Value {
    let mut value = serde_json::to_value(plan).unwrap();
    normalize_cleanup_json(root, &mut value);
    value
}

fn write_cleanup_trace(root: &Path, trace: &serde_json::Value) {
    let bytes = serde_json::to_vec_pretty(trace).unwrap();
    let text = String::from_utf8(bytes.clone()).unwrap();
    assert!(
        !text.contains(&root.to_string_lossy().to_string()),
        "the stable trace must not contain its temporary root"
    );
    fs::write(root.join("cleanup-equivalence-trace.json"), bytes).unwrap();
}

fn write_single_resume_trace(
    root: &Path,
    scenario: &str,
    plan: &CleanupPlan,
    tree_before: Vec<serde_json::Value>,
    result: &str,
) {
    let tree_after = cleanup_tree_snapshot(root);
    let persisted_after = read_cleanup_plan(root, &plan.cleanup_id).unwrap();
    write_cleanup_trace(
        root,
        &serde_json::json!({
            "scenario": scenario,
            "tree_before": tree_before,
            "memory_plan_before": stable_cleanup_plan(root, plan),
            "persisted_plan_before": stable_cleanup_plan(root, plan),
            "operation": result,
            "tree_after": tree_after,
            "memory_plan_after": null,
            "persisted_plan_after": stable_cleanup_plan(root, &persisted_after),
        }),
    );
}

fn cleanup_source_fixture(root: &Path) -> (PathBuf, String) {
    let source_path = root.join("source.wav");
    let mut writer = crate::parakeet_audio::PcmPartWriter::create(&source_path).unwrap();
    writer.append(&vec![0_i16; 160]).unwrap();
    writer.finish().unwrap();
    let source_sha256 = hex(&sha256_file(&source_path).unwrap());
    (source_path, source_sha256)
}

struct CleanupFixtureSuccessor {
    treatment: TreatmentIdentity,
    path: PathBuf,
    identity: CleanupObjectIdentity,
    files: Vec<CleanupObject>,
    index: CleanupObject,
}

fn cleanup_successor_fixture(root: &Path, source_sha256: &str) -> CleanupFixtureSuccessor {
    use crate::windows_file_identity::inspect;

    let successor = TreatmentIdentity {
        destination: root.canonicalize().unwrap().to_string_lossy().into_owned(),
        job_id: JobId(0x7401),
        generation: Generation::first(),
    };
    let successor_path = generation_path(root, successor.job_id, successor.generation);
    fs::create_dir_all(&successor_path).unwrap();
    fs::write(successor_path.join("transcript.txt"), b"new transcript").unwrap();
    fs::write(successor_path.join("transcript.srt"), b"new subtitle\n").unwrap();
    fs::write(successor_path.join("segments.jsonl"), b"").unwrap();
    let pending = PendingRecord {
        version: 4,
        job_id: successor.job_id,
        generation: successor.generation,
        source_path: "source.wav".into(),
        source_sha256: source_sha256.into(),
        source_samples: 160,
        model_path: "synthetic-model.gguf".into(),
        model_sha256: APPROVED_MODEL_SHA256.into(),
        model_size: APPROVED_MODEL_SIZE,
        strategy: whisper_core::parakeet_session::TranscriptionStrategy::LegacyV1,
        qualification: None,
    };
    fs::write(
        successor_path.join("pending.json"),
        serde_json::to_vec(&pending).unwrap(),
    )
    .unwrap();
    let text = verified_artifact(&successor_path, &successor_path.join("transcript.txt")).unwrap();
    let srt = verified_artifact(&successor_path, &successor_path.join("transcript.srt")).unwrap();
    fs::write(
        successor_path.join("manifest.json"),
        serde_json::to_vec(&CompleteRecord {
            version: 1,
            job_id: successor.job_id,
            generation: successor.generation,
            source_sha256: source_sha256.into(),
            segments: 0,
            text,
            srt,
        })
        .unwrap(),
    )
    .unwrap();
    let cleanup_id = "cleanup-equivalence";
    fs::write(
        successor_path.join("r11-publication.json"),
        serde_json::to_vec(&PublicationIntent {
            version: 1,
            operation_id: cleanup_id.into(),
            choice: DuplicateImportChoice::Replace,
            source_sha256: source_sha256.into(),
            source_samples: 160,
            expected_active: Vec::new(),
            export_basename: "fixture".into(),
            internal_only: true,
            cleanup_id: Some(cleanup_id.into()),
            cleanup_targets: Vec::new(),
        })
        .unwrap(),
    )
    .unwrap();
    fs::write(successor_path.join("CURRENT"), b"manifest.json\n").unwrap();
    let index = PublicationIndex {
        version: 1,
        records: vec![PublicationRecord {
            job_id: successor.job_id,
            generation: successor.generation,
            source_sha256: source_sha256.into(),
            export_basename: Some("fixture".into()),
            active: true,
            success_ordinal: Some(1),
        }],
    };
    write_publication_index(root, &index).unwrap();

    let mut files = capture_successor_files(root, &successor_path).unwrap();
    files.push(capture_cleanup_file(root, &successor_path.join("CURRENT")).unwrap());
    let successor_identity = identity_snapshot(inspect(&successor_path, true).unwrap()).unwrap();
    let index_proof = capture_cleanup_file(root, &publication_index_path(root)).unwrap();
    CleanupFixtureSuccessor {
        treatment: successor,
        path: successor_path,
        identity: successor_identity,
        files,
        index: index_proof,
    }
}

fn cleanup_old_target_fixture(
    root: &Path,
    successor: &TreatmentIdentity,
    source_sha256: &str,
    unowned_obstacle: bool,
) -> CleanupTarget {
    use crate::windows_file_identity::inspect;

    let old_job = JobId(0x7402);
    let old_directory = generation_path(root, old_job, Generation::first());
    fs::create_dir_all(&old_directory).unwrap();
    let owned_file = old_directory.join("owned.txt");
    fs::write(&owned_file, b"owned old artifact").unwrap();
    let mut objects = vec![CleanupObject {
        relative_path: cleanup_relative(root, &owned_file),
        identity: identity_snapshot(inspect(&owned_file, false).unwrap()).unwrap(),
        sha256: Some(hex(&sha256_file(&owned_file).unwrap())),
        owned: true,
        removed: false,
        error: None,
    }];
    if unowned_obstacle {
        let obstacle = old_directory.join("unselected.txt");
        fs::write(&obstacle, b"third party").unwrap();
        objects.push(CleanupObject {
            relative_path: cleanup_relative(root, &obstacle),
            identity: identity_snapshot(inspect(&obstacle, false).unwrap()).unwrap(),
            sha256: Some(hex(&sha256_file(&obstacle).unwrap())),
            owned: false,
            removed: false,
            error: Some("fixture obstacle".into()),
        });
    }
    objects.push(CleanupObject {
        relative_path: cleanup_relative(root, &old_directory),
        identity: identity_snapshot(inspect(&old_directory, true).unwrap()).unwrap(),
        sha256: None,
        owned: true,
        removed: false,
        error: None,
    });
    let old_container = old_directory.parent().unwrap();
    CleanupTarget {
        treatment: TreatmentIdentity {
            destination: successor.destination.clone(),
            job_id: old_job,
            generation: Generation::first(),
        },
        source_sha256: source_sha256.into(),
        ancestors: [root.join("transcriptions"), old_container.to_path_buf()]
            .into_iter()
            .map(|path| CleanupAncestor {
                relative_path: cleanup_relative(root, &path),
                identity: identity_snapshot(inspect(&path, true).unwrap()).unwrap(),
            })
            .collect(),
        objects,
        container: Some(CleanupObject {
            relative_path: cleanup_relative(root, old_container),
            identity: identity_snapshot(inspect(old_container, true).unwrap()).unwrap(),
            sha256: None,
            owned: true,
            removed: false,
            error: None,
        }),
    }
}

fn cleanup_fixture(root: &Path, unowned_obstacle: bool) -> CleanupPlan {
    let (source_path, source_sha256) = cleanup_source_fixture(root);
    let successor = cleanup_successor_fixture(root, &source_sha256);
    let target =
        cleanup_old_target_fixture(root, &successor.treatment, &source_sha256, unowned_obstacle);
    let targets = vec![target];
    let intent_path = successor.path.join("r11-publication.json");
    let mut intent: PublicationIntent =
        serde_json::from_slice(&fs::read(intent_path).unwrap()).unwrap();
    intent.cleanup_targets = targets.clone();
    fs::write(
        successor.path.join("r11-publication.json"),
        serde_json::to_vec(&intent).unwrap(),
    )
    .unwrap();
    let plan = CleanupPlan {
        version: 1,
        cleanup_id: "cleanup-equivalence".into(),
        destination: successor.treatment.destination.clone(),
        source_path: source_path.to_string_lossy().into_owned(),
        source_sha256,
        successor: successor.treatment,
        successor_directory: successor.identity,
        successor_files: successor.files,
        successor_index: Some(successor.index),
        published: true,
        targets,
        last_error: None,
    };
    write_cleanup_plan(root, &plan).unwrap();
    plan
}

fn cleanup_fixture_without_targets(root: &Path) -> CleanupPlan {
    let mut plan = cleanup_fixture(root, false);
    plan.targets.clear();
    let successor_path = generation_path(root, plan.successor.job_id, plan.successor.generation);
    let intent_path = successor_path.join("r11-publication.json");
    let mut intent: PublicationIntent =
        serde_json::from_slice(&fs::read(&intent_path).unwrap()).unwrap();
    intent.cleanup_targets.clear();
    fs::write(&intent_path, serde_json::to_vec(&intent).unwrap()).unwrap();
    plan.successor_files = capture_successor_files(root, &successor_path).unwrap();
    plan.successor_files
        .push(capture_cleanup_file(root, &successor_path.join("CURRENT")).unwrap());
    write_cleanup_plan(root, &plan).unwrap();
    plan
}

#[test]
fn cleanup_characterization_nonempty_generation_persists_partial_removal_and_resumes() {
    let root = archive_characterization_root("cleanup-d06");
    let plan = cleanup_fixture(&root, true);
    let tree_before = cleanup_tree_snapshot(&root);
    let memory_before = stable_cleanup_plan(&root, &plan);
    let disk_before =
        stable_cleanup_plan(&root, &read_cleanup_plan(&root, &plan.cleanup_id).unwrap());
    let target = &plan.targets[0];
    let owned = root.join(&target.objects[0].relative_path);
    let obstacle = root.join(&target.objects[1].relative_path);
    let generation_dir = root.join(&target.objects[2].relative_path);

    let first = ArchiveStore::resume_replacement_cleanup(&root, &plan.cleanup_id).unwrap_err();
    assert!(first.starts_with("StorageUnavailable:"), "{first}");
    assert!(
        !owned.exists(),
        "the owned file is removed before directory disposition"
    );
    assert!(obstacle.exists(), "the unowned file is retained");
    assert!(
        generation_dir.is_dir(),
        "the nonempty generation directory remains"
    );
    let persisted = read_cleanup_plan(&root, &plan.cleanup_id).unwrap();
    let tree_after_failure = cleanup_tree_snapshot(&root);
    let disk_after_failure = stable_cleanup_plan(&root, &persisted);
    assert!(persisted.targets[0].objects[0].removed);
    assert!(!persisted.targets[0].objects[1].removed);
    assert!(persisted.last_error.is_some());

    fs::remove_file(&obstacle).unwrap();
    let tree_before_retry = cleanup_tree_snapshot(&root);
    ArchiveStore::resume_replacement_cleanup(&root, &plan.cleanup_id).unwrap();
    let resumed = read_cleanup_plan(&root, &plan.cleanup_id).unwrap();
    let tree_after_retry = cleanup_tree_snapshot(&root);
    assert!(
        resumed.targets[0]
            .objects
            .iter()
            .all(|object| object.removed)
    );
    assert!(resumed.targets[0].container.as_ref().unwrap().removed);
    assert!(resumed.last_error.is_none());
    assert!(!generation_dir.exists());
    assert!(!generation_dir.parent().unwrap().exists());
    write_cleanup_trace(
        &root,
        &serde_json::json!({
            "scenario": "D06-nonempty-generation-partial-removal-resume",
            "before": tree_before,
            "memory_plan_before": memory_before,
            "persisted_plan_before": disk_before,
            "first_resume": {
                "result": first,
                "tree_after": tree_after_failure,
                "persisted_plan_after": disk_after_failure,
            },
            "remove_unowned_obstacle": {
                "tree_before": tree_before_retry,
                "relative_path": cleanup_relative(&root, &obstacle),
            },
            "second_resume": {
                "result": "Ok",
                "tree_after": tree_after_retry,
                "plan_as_loaded_after": stable_cleanup_plan(&root, &resumed),
                "persisted_plan_after": stable_cleanup_plan(&root, &resumed),
            },
        }),
    );
}

#[test]
fn cleanup_characterization_locked_file_preserves_target_until_retry() {
    use std::{fs::OpenOptions, os::windows::fs::OpenOptionsExt};

    let root = archive_characterization_root("cleanup-d04");
    let plan = cleanup_fixture(&root, false);
    let target = &plan.targets[0];
    let owned = root.join(&target.objects[0].relative_path);
    let generation_dir = root.join(&target.objects[1].relative_path);
    let tree_before = cleanup_tree_snapshot(&root);
    let lock = OpenOptions::new()
        .read(true)
        .share_mode(0x1 | 0x2)
        .open(&owned)
        .unwrap();

    let first = ArchiveStore::resume_replacement_cleanup(&root, &plan.cleanup_id).unwrap_err();
    assert!(first.starts_with("StorageUnavailable:"), "{first}");
    assert!(owned.exists(), "the locked owned file remains present");
    assert!(generation_dir.is_dir());
    let persisted = read_cleanup_plan(&root, &plan.cleanup_id).unwrap();
    assert!(!persisted.targets[0].objects[0].removed);
    assert!(persisted.last_error.is_some());
    let tree_after_failure = cleanup_tree_snapshot(&root);
    let persisted_after_failure = stable_cleanup_plan(&root, &persisted);

    drop(lock);
    ArchiveStore::resume_replacement_cleanup(&root, &plan.cleanup_id).unwrap();
    let resumed = read_cleanup_plan(&root, &plan.cleanup_id).unwrap();
    let tree_after_retry = cleanup_tree_snapshot(&root);
    assert!(
        resumed.targets[0]
            .objects
            .iter()
            .all(|object| object.removed)
    );
    assert!(resumed.targets[0].container.as_ref().unwrap().removed);
    assert!(!owned.exists());
    assert!(!generation_dir.exists());
    assert!(!generation_dir.parent().unwrap().exists());
    write_cleanup_trace(
        &root,
        &serde_json::json!({
            "scenario": "D04-locked-file-then-retry",
            "tree_before": tree_before,
            "memory_plan_before": stable_cleanup_plan(&root, &plan),
            "first_resume": {
                "result": first,
                "tree_after": tree_after_failure,
                "persisted_plan_after": persisted_after_failure,
            },
            "release_lock": "standard file handle dropped",
            "second_resume": {
                "result": "Ok",
                "tree_after": tree_after_retry,
                "persisted_plan_after": stable_cleanup_plan(&root, &resumed),
            },
        }),
    );
}

#[test]
fn cleanup_characterization_nominal_plan_removes_only_owned_target() {
    let root = archive_characterization_root("cleanup-nominal");
    let plan = cleanup_fixture(&root, false);
    let target = &plan.targets[0];
    let owned = root.join(&target.objects[0].relative_path);
    let generation_dir = root.join(&target.objects[1].relative_path);
    let container = root.join(&target.container.as_ref().unwrap().relative_path);
    let tree_before = cleanup_tree_snapshot(&root);

    ArchiveStore::resume_replacement_cleanup(&root, &plan.cleanup_id).unwrap();
    let completed = read_cleanup_plan(&root, &plan.cleanup_id).unwrap();
    assert!(
        completed.targets[0]
            .objects
            .iter()
            .all(|object| object.removed)
    );
    assert!(completed.targets[0].container.as_ref().unwrap().removed);
    assert!(completed.last_error.is_none());
    assert!(!owned.exists());
    assert!(!generation_dir.exists());
    assert!(!container.exists());
    write_single_resume_trace(
        &root,
        "D02-nominal-owned-target-removal",
        &plan,
        tree_before,
        "Ok",
    );
}

#[test]
fn cleanup_characterization_absent_file_is_recorded_then_remaining_target_is_removed() {
    let root = archive_characterization_root("cleanup-absent");
    let plan = cleanup_fixture(&root, false);
    let target = &plan.targets[0];
    let owned = root.join(&target.objects[0].relative_path);
    let generation_dir = root.join(&target.objects[1].relative_path);
    fs::remove_file(&owned).unwrap();
    let tree_before = cleanup_tree_snapshot(&root);

    ArchiveStore::resume_replacement_cleanup(&root, &plan.cleanup_id).unwrap();
    let completed = read_cleanup_plan(&root, &plan.cleanup_id).unwrap();
    assert!(
        completed.targets[0]
            .objects
            .iter()
            .all(|object| object.removed)
    );
    assert!(completed.targets[0].container.as_ref().unwrap().removed);
    assert!(completed.last_error.is_none());
    assert!(!generation_dir.exists());
    write_single_resume_trace(&root, "D03-already-absent-file", &plan, tree_before, "Ok");
}

#[test]
fn cleanup_characterization_empty_target_list_preserves_successor_and_persists_empty_plan() {
    let root = archive_characterization_root("cleanup-empty");
    let plan = cleanup_fixture_without_targets(&root);
    let successor_path = generation_path(&root, plan.successor.job_id, plan.successor.generation);
    let tree_before = cleanup_tree_snapshot(&root);

    ArchiveStore::resume_replacement_cleanup(&root, &plan.cleanup_id).unwrap();
    let completed = read_cleanup_plan(&root, &plan.cleanup_id).unwrap();
    assert!(completed.targets.is_empty());
    assert!(completed.last_error.is_none());
    assert!(successor_path.join("CURRENT").is_file());
    assert!(successor_path.join("manifest.json").is_file());
    write_single_resume_trace(&root, "D01-empty-target-list", &plan, tree_before, "Ok");
}

#[test]
fn cleanup_characterization_new_unselected_file_is_preserved_after_partial_removal() {
    let root = archive_characterization_root("cleanup-added-file");
    let plan = cleanup_fixture(&root, false);
    let target = &plan.targets[0];
    let owned = root.join(&target.objects[0].relative_path);
    let generation_dir = root.join(&target.objects[1].relative_path);
    let added = generation_dir.join("added-after-selection.txt");
    fs::write(&added, b"unselected data").unwrap();
    let tree_before = cleanup_tree_snapshot(&root);

    let first = ArchiveStore::resume_replacement_cleanup(&root, &plan.cleanup_id).unwrap_err();
    assert!(first.starts_with("StorageUnavailable:"), "{first}");
    assert!(
        !owned.exists(),
        "the previously selected owned file is removed"
    );
    assert!(
        added.exists(),
        "the unselected file added after selection is kept"
    );
    assert!(generation_dir.is_dir());
    let persisted = read_cleanup_plan(&root, &plan.cleanup_id).unwrap();
    let added_record = persisted.targets[0]
        .objects
        .iter()
        .find(|object| object.relative_path == cleanup_relative(&root, &added))
        .expect("the new item is added to the durable plan");
    assert!(!added_record.owned);
    assert!(!added_record.removed);
    assert!(
        added_record
            .error
            .as_deref()
            .unwrap()
            .contains("ajouté après confirmation")
    );
    assert!(persisted.last_error.is_some());
    write_single_resume_trace(
        &root,
        "D05-added-unselected-file-preserved",
        &plan,
        tree_before,
        &first,
    );
}
