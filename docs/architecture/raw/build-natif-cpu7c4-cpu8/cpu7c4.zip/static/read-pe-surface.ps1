# One-shot BUILD-NATIF evidence parser; archived with results, not a permanent guard.
function Get-NativePeSurface([string]$Path) {
    $b=[IO.File]::ReadAllBytes($Path)
    function Range([long]$p,[long]$n) { if($p -lt 0 -or $n -lt 0 -or $p+$n -gt $b.LongLength){throw "PE bounds: $p + $n"} }
    function U16([long]$p) { Range $p 2; [BitConverter]::ToUInt16($b,[int]$p) }
    function U32([long]$p) { Range $p 4; [BitConverter]::ToUInt32($b,[int]$p) }
    function U64([long]$p) { Range $p 8; [BitConverter]::ToUInt64($b,[int]$p) }
    if((U16 0) -ne 0x5a4d){throw 'PE missing MZ'}
    $pe=[long](U32 60);Range $pe 24
    if((U32 $pe) -ne 0x4550 -or (U16 ($pe+4)) -ne 0x8664){throw 'Expected x64 PE'}
    $opt=$pe+24
    if((U16 $opt) -ne 0x20b -or (U16 ($pe+20)) -lt 240){throw 'Expected complete PE32+ optional header'}
    $imageBase=U64 ($opt+24);$headers=U32 ($opt+60)
    $sections=$opt+(U16 ($pe+20));$sectionCount=U16 ($pe+6)
    if($sectionCount -lt 1 -or $sectionCount -gt 96){throw 'Unexpected PE section count'}
    Range $sections (40*$sectionCount)
    function Map([long]$rva) {
        if($rva -lt 0){throw 'Negative PE RVA'}
        if($rva -lt $headers){Range $rva 1;return $rva}
        for($s=0;$s -lt $sectionCount;$s++){
            $at=$sections+40*$s;$start=U32 ($at+12);$rawSize=U32 ($at+16)
            if($rva -ge $start -and $rva -lt ([long]$start+$rawSize)){$p=[long](U32 ($at+20))+$rva-$start;Range $p 1;return $p}
        };throw "Unmapped PE RVA $rva"
    }
    function Ansi([long]$p) {
        Range $p 1;$end=$p
        while($end -lt $b.LongLength -and $end-$p -lt 4096 -and $b[$end] -ne 0){$end++}
        if($end -ge $b.LongLength -or $end-$p -ge 4096){throw 'Unterminated PE string'}
        [Text.Encoding]::ASCII.GetString($b,[int]$p,[int]($end-$p))
    }
    $exports=[Collections.Generic.List[string]]::new();$imports=[Collections.Generic.List[string]]::new()
    $exportRva=U32 ($opt+112)
    if($exportRva){
        $e=Map $exportRva;Range $e 40
        $baseOrdinal=U32 ($e+16);$functions=U32 ($e+20);$names=U32 ($e+24)
        if($functions -gt 65536 -or $names -gt 65536){throw 'Unbounded PE export table'}
        $functionTable=Map (U32 ($e+28));$nameTable=Map (U32 ($e+32));$ordinalTable=Map (U32 ($e+36))
        $byOrdinal=@{}
        for($i=0;$i -lt $names;$i++){
            $ordinal=U16 ($ordinalTable+2*$i)
            if($ordinal -ge $functions){throw 'Export ordinal exceeds function count'}
            $name=Ansi (Map (U32 ($nameTable+4*$i)))
            if(-not $byOrdinal.ContainsKey([int]$ordinal)){$byOrdinal[[int]$ordinal]=[Collections.Generic.List[string]]::new()}
            $byOrdinal[[int]$ordinal].Add($name)
        }
        for($i=0;$i -lt $functions;$i++){
            if((U32 ($functionTable+4*$i)) -eq 0){continue}
            $ordinal=[long]$baseOrdinal+$i
            if($byOrdinal.ContainsKey([int]$i)){foreach($name in $byOrdinal[[int]$i]){$exports.Add("${ordinal}|$name")}}
            else{$exports.Add("${ordinal}|<ordinal-only>")}
        }
    }
    $ordinalFlag=[uint64]::Parse('8000000000000000',[Globalization.NumberStyles]::HexNumber)
    function Add-Thunks([long]$rva,[string]$dll,[string]$kind) {
        $p=Map $rva;$terminated=$false
        for($t=0;$t -lt 65536;$t++){
            $value=U64 ($p+8*$t)
            if($value -eq 0){$terminated=$true;break}
            if(($value -band $ordinalFlag) -ne 0){$symbol='#'+($value -band 65535)}
            else{if($value -gt [uint32]::MaxValue){throw 'Invalid name RVA in import thunk'};$symbol=Ansi ((Map ([long]$value))+2)}
            $imports.Add("$kind|$($dll.ToLowerInvariant())|$symbol")
        }
        if(-not $terminated){throw 'Unterminated PE import thunk table'}
    }
    foreach($kind in @('direct','delay')){
        $index=if($kind -eq 'direct'){1}else{13};$width=if($kind -eq 'direct'){20}else{32}
        $rva=U32 ($opt+112+8*$index);$size=U32 ($opt+116+8*$index)
        if(-not $rva -and -not $size){continue}
        if(-not $rva -or $size -lt $width){throw 'Invalid PE import directory'}
        $p=Map $rva;$terminated=$false
        for($offset=0;$offset+$width -le $size;$offset+=$width){
            Range ($p+$offset) $width;$d=$p+$offset;$zero=$true
            for($field=0;$field -lt $width;$field+=4){if((U32 ($d+$field)) -ne 0){$zero=$false;break}}
            if($zero){$terminated=$true;break}
            if($kind -eq 'direct'){
                $dll=Ansi (Map (U32 ($d+12)));$thunk=U32 $d
                if(-not $thunk){$thunk=U32 ($d+16)}
            }else{
                $attributes=U32 $d
                if($attributes -notin @(0,1)){throw 'Unsupported delay descriptor attributes'}
                $name=[long](U32 ($d+4));$thunk=[long](U32 ($d+16))
                if(-not $thunk){throw 'Missing delay import name table'}
                if($attributes -eq 0){$name-=[long]$imageBase;$thunk-=[long]$imageBase}
                $dll=Ansi (Map $name)
            }
            Add-Thunks $thunk $dll $kind
        }
        if(-not $terminated){throw 'Unterminated PE descriptor table'}
    }
    [pscustomobject]@{path=$Path;bytes=$b.LongLength;sha256=(Get-FileHash -LiteralPath $Path).Hash;exports=@($exports.ToArray()|Sort-Object -CaseSensitive);imports=@($imports.ToArray()|Sort-Object -CaseSensitive)}
}
