$ErrorActionPreference='Stop'
$repo='C:\wt\build-natif'
$out=Join-Path $repo 'docs/architecture/raw/build-natif-cpu7c4-cpu8'
if(Test-Path -LiteralPath $out){
    if(@(Get-ChildItem -LiteralPath $out -Force).Count){throw 'Archive destination is not empty; no overwrite.'}
}else{New-Item -ItemType Directory -Path $out | Out-Null}
function New-Entries { return ,[Collections.Generic.List[object]]::new() }
function Add-One($Entries,[string]$File,[string]$Name) {
    if(-not(Test-Path -LiteralPath $File -PathType Leaf)){throw "Required proof missing: $File"}
    $Entries.Add([pscustomobject]@{file=$File;name=$Name.Replace('\','/')})
}
function Add-Tree($Entries,[string]$Root,[string]$Prefix) {
    foreach($f in Get-ChildItem -LiteralPath $Root -Recurse -Force -File){
        if($f.Extension -in @('.obj','.pdb')){continue}
        Add-One $Entries $f.FullName ($Prefix+'/'+[IO.Path]::GetRelativePath($Root,$f.FullName))
    }
}
function Add-Direct($Entries,[string]$Root,[string]$Prefix,[string]$Filter='*') {
    foreach($f in Get-ChildItem -LiteralPath $Root -File -Filter $Filter){Add-One $Entries $f.FullName ($Prefix+'/'+$f.Name)}
}
function Save-Archive($Entries,[string]$Name) {
    $names=[Collections.Generic.HashSet[string]]::new([StringComparer]::Ordinal)
    $manifest=@(foreach($e in $Entries){
        if(-not $names.Add($e.name)){throw 'Duplicate input proof name.'}
        [ordered]@{path=$e.name;bytes=(Get-Item -LiteralPath $e.file).Length;sha256=(Get-FileHash -LiteralPath $e.file -Algorithm SHA256).Hash.ToLowerInvariant()}
    })
    $path=Join-Path $out $Name
    $zip=[IO.Compression.ZipFile]::Open($path,[IO.Compression.ZipArchiveMode]::Create)
    try{
        for($i=0;$i -lt $Entries.Count;$i++){[void][IO.Compression.ZipFileExtensions]::CreateEntryFromFile($zip,$Entries[$i].file,$manifest[$i].path,[IO.Compression.CompressionLevel]::Optimal)}
        $w=[IO.StreamWriter]::new($zip.CreateEntry('manifest.json').Open(),[Text.UTF8Encoding]::new($false))
        try{$w.Write((ConvertTo-Json -InputObject $manifest -Depth 6))}finally{$w.Dispose()}
    }finally{$zip.Dispose()}
    $zip=[IO.Compression.ZipFile]::OpenRead($path)
    try{
        $r=[IO.StreamReader]::new($zip.GetEntry('manifest.json').Open())
        try{$verified=ConvertFrom-Json -InputObject $r.ReadToEnd()}finally{$r.Dispose()}
        if($zip.Entries.Count -ne $verified.Count+1){throw 'Archive count mismatch.'}
        $seen=[Collections.Generic.HashSet[string]]::new([StringComparer]::Ordinal)
        foreach($e in $zip.Entries){if(-not $seen.Add($e.FullName)){throw 'Archive duplicate.'}}
        foreach($f in $verified){
            $e=$zip.GetEntry($f.path);if($null -eq $e -or $e.Length -ne $f.bytes){throw 'Archive size mismatch.'}
            $s=$e.Open();try{if([Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($s)).ToLowerInvariant() -cne $f.sha256){throw 'Archive SHA mismatch.'}}finally{$s.Dispose()}
        }
    }finally{$zip.Dispose()}
    return [ordered]@{archive=$path;files=$manifest.Count;bytes=(Get-Item -LiteralPath $path).Length;sha256=(Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash.ToLowerInvariant();verification='count/names/lengths/SHA PASS'}
}
$first=New-Entries
Add-Tree $first (Join-Path $repo 'target/native-build/cpu/cpu7c4') 'build'
Add-Direct $first (Join-Path $repo 'target/native-build/guard/NativeDllCpu-cpu7c4') 'guard'
Add-Tree $first (Join-Path $repo 'target/native-build/cpu7c4-static') 'static'
$previous=Join-Path $repo 'target/native-build/guard/NativeDllCpu-cpu8/previous-workspace'
foreach($name in @('CMakeCache.txt','build.ninja','compile_commands.json','.ninja_log')){
    $p=Join-Path $previous "build/$name";if(Test-Path -LiteralPath $p -PathType Leaf){Add-One $first $p "cmake/$name"}
}
Add-Direct $first (Join-Path $previous 'src/vcpkg/buildtrees/protobuf') 'protobuf' '*.log'
Add-One $first (Join-Path $repo 'docs/architecture/raw/native-build/installed-inventory.json') 'installed-inventory.json'
$second=New-Entries
Add-Tree $second (Join-Path $repo 'target/native-build/cpu/cpu8') 'build'
Add-Direct $second (Join-Path $repo 'target/native-build/guard/NativeDllCpu-cpu8') 'guard'
$protobuf='C:\wb\native\cpu\src\vcpkg\buildtrees\protobuf'
Add-Direct $second $protobuf 'protobuf'
foreach($name in @('CMakeCache.txt','build.ninja','.ninja_log','CMakeFiles/rules.ninja')){
    $p=Join-Path $protobuf "x64-windows-rel/$name";if(Test-Path -LiteralPath $p -PathType Leaf){Add-One $second $p "protobuf-release/$name"}
}
foreach($name in @('any_lite.cc','message_lite.h')){Add-One $second (Join-Path $protobuf "src/v33.4-f8b43d71cd.clean/src/google/protobuf/$name") "protobuf-source/$name"}
foreach($name in @('protobuf-cpu8-static-diagnostic.json','cpu8-windows-events.json','cpu8-msvc-identity.json','compare-cpu-repeat.ps1')){Add-One $second (Join-Path $repo "target/native-build/$name") "diagnostic/$name"}
foreach($entries in @($first,$second)){
    foreach($name in @('ci/build-native.ps1','ci/guard-native.ps1','ci/native-build-control.cs','ci/native-directory-watch.cs','ci/native-workspace.ps1','native/build-config.json','native/patches/ggml-pinned-build-commit.patch')){Add-One $entries (Join-Path $repo $name) "context/$name"}
    Add-One $entries $PSCommandPath 'archive-cpu-resume.ps1'
}
$results=@((Save-Archive $first 'cpu7c4.zip'),(Save-Archive $second 'cpu8-stop.zip'))
ConvertTo-Json -InputObject $results -Depth 6 | Set-Content -LiteralPath (Join-Path $repo 'target/native-build/cpu-resume-archives.json') -Encoding utf8NoBOM
$results | ConvertTo-Json -Depth 6
