# One-shot BUILD-NATIF proof; archive this source with its outputs. Never loads a DLL.
param([string]$First='cpu7c4',[string]$Second='cpu8')
$ErrorActionPreference='Stop'
$repo='C:\wt\build-natif'
$root=Join-Path $repo "target/native-build/static-$First-$Second"
if(Test-Path -LiteralPath $root){throw 'Proof directory exists; no overwrite.'}
New-Item -ItemType Directory $root | Out-Null
. (Join-Path $repo 'target/native-build/read-pe-surface.ps1')
$peScript=Join-Path $repo 'ci/check-worker-imports.ps1'
$ast=[Management.Automation.Language.Parser]::ParseFile($peScript,[ref]$null,[ref]$null)
foreach($f in $ast.FindAll({param($n) $n -is [Management.Automation.Language.FunctionDefinitionAst]},$false)) { Invoke-Expression $f.Extent.Text }
$cudaPattern='^(cublas(?:lt)?|cudart|nvcuda|cudnn|nvrtc|cufft|curand|cusparse).*\.dll$'
$rows=[Collections.Generic.List[object]]::new()
$sources=[Collections.Generic.List[object]]::new()
$a=Get-Content (Join-Path $repo "target/native-build/cpu/$First/manifest.json") -Raw | ConvertFrom-Json
$b=Get-Content (Join-Path $repo "target/native-build/cpu/$Second/manifest.json") -Raw | ConvertFrom-Json
function Canonical($Options) { ($Options.PSObject.Properties | Sort-Object Name | ForEach-Object { $_.Name+'='+[string]$_.Value }) -join "`n" }
$requestedEqual=(Canonical $a.requestedOptions) -ceq (Canonical $b.requestedOptions)
$effectiveDifferences=@(foreach($key in @($a.effectiveOptions.PSObject.Properties.Name + $b.effectiveOptions.PSObject.Properties.Name | Sort-Object -Unique)) {
    if([string]$a.effectiveOptions.$key -cne [string]$b.effectiveOptions.$key){[ordered]@{key=$key;first=$a.effectiveOptions.$key;second=$b.effectiveOptions.$key}}
})
$inventory=Get-Content (Join-Path $repo 'docs/architecture/raw/native-build/installed-inventory.json') -Raw | ConvertFrom-Json
$status='FAIL'; $failure=$null
try {
    if($a.status -cne 'BUILT_NOT_QUALIFIED' -or $b.status -cne 'BUILT_NOT_QUALIFIED'){throw 'A build is not complete.'}
    if($a.ggmlCommit -cne 'bd4f514db14d87fded667787a7a963bfbaa98e89' -or $a.ggmlCommit -cne $b.ggmlCommit){throw 'Decoded source commit mismatch.'}
    if($a.configSha256 -cne $b.configSha256 -or -not $requestedEqual){throw 'Build configuration mismatch.'}
    foreach($name in @('ggml-base.dll','ggml.dll','ggml-cpu.dll','nemo_speech_asr.dll','nemo_speech_asr_c.dll')) {
        $installed=Join-Path $env:LOCALAPPDATA "Whisper/native/cpu/$name"
        $p1=Join-Path $repo "target/native-build/cpu/$First/dll/$name"
        $p2=Join-Path $repo "target/native-build/cpu/$Second/dll/$name"
        $old=Get-NativePeSurface $installed; $one=Get-NativePeSurface $p1; $two=Get-NativePeSurface $p2
        $historical=@($inventory | Where-Object RelativePath -IEQ "cpu\$name")
        if($historical.Count -ne 1 -or $historical[0].Sha256 -ine $old.sha256){throw "Installed baseline changed: $name"}
        $repeat=$one.sha256 -ceq $two.sha256
        $exports=($old.exports -join "`n") -ceq ($two.exports -join "`n")
        $imports=($old.imports -join "`n") -ceq ($two.imports -join "`n")
        $noCuda=Invoke-Check 'ParakeetCpu' $p2
        if(@($two.imports | Where-Object { $_ -match '\|ggml-cuda\.dll\|' }).Count){throw 'CPU links ggml-cuda.dll.'}
        $row=[ordered]@{dll=$name;installedSha256=$old.sha256;firstSha256=$one.sha256;secondSha256=$two.sha256;repeatable=$repeat;exportsEqual=$exports;importsEqual=$imports;noCuda=$noCuda.Verdict;installedBytes=$old.bytes;rebuiltBytes=$two.bytes;sizeDeltaPct=100.0*($two.bytes-$old.bytes)/$old.bytes;exports=$two.exports.Count;imports=$two.imports.Count}
        $rows.Add($row);$sources.Add(@{installed=$old;first=$one;second=$two;noCuda=$noCuda})
        if(-not $repeat -or -not $exports -or -not $imports -or $noCuda.Verdict -cne 'PASS'){throw "Static criterion failed: $name"}
        if([math]::Abs($row.sizeDeltaPct) -gt 2){throw "Size deviation above two percent: $name"}
    }
    $status='PASS'
} catch { $failure=$_.Exception.Message; throw }
finally {
    @{status=$status;failure=$failure;first=$First;second=$Second;ggmlCommit=$b.ggmlCommit;requestedOptionsEqual=$requestedEqual;effectiveDifferences=$effectiveDifferences;rows=$rows;exportsScope='name+ordinal (including ordinal-only), no forwarding target comparison';importsScope='DLL+symbols/ordinals, direct and delay';functional='NON EXECUTE'} | ConvertTo-Json -Depth 9 | Set-Content (Join-Path $root comparison.json) -Encoding utf8NoBOM
    $sources | ConvertTo-Json -Depth 12 | Set-Content (Join-Path $root surfaces.json) -Encoding utf8NoBOM
    Copy-Item -LiteralPath $PSCommandPath,(Join-Path $repo 'target/native-build/read-pe-surface.ps1'),$peScript -Destination $root
}
"PASS CPU repetition and installed PE surfaces: $root"
