include!("tests/unified_support.rs");
include!("tests/unified_import.rs");
include!("tests/unified_capture.rs");
include!("tests/native_execution.rs");
include!("tests/microphone_and_finalization.rs");
include!("tests/reprocessing_and_transport.rs");
include!("tests/resume_and_admission.rs");
include!("tests/queue_characterization.rs");
include!("tests/duplicate_characterization.rs");
include!("tests/effect_characterization.rs");
include!("tests/source_binding_entry.rs");
include!("tests/worker_command_poll.rs");

include!("tests/unified_restart_and_pages.rs");
include!("tests/queue_inspection_characterization.rs");
