mod queue_inspection_characterization {
use super::*;
use crate::model_catalog::model_sha256_full_read_count;
use whisper_core::{model_catalog::ModelId, model_registry::model};

struct ModelInspectionFixture(PathBuf);

impl Drop for ModelInspectionFixture {
    fn drop(&mut self) {
        let _ = fs::remove_dir_all(&self.0);
    }
}

fn inspection_fixture(label: &str) -> (ModelInspectionFixture, ImportRequest, PathBuf, PathBuf) {
    let root = test_artifact_root(label);
    fs::create_dir_all(&root).unwrap();
    let models = root.join("models");
    fs::create_dir_all(&models).unwrap();
    let turbo = models.join(model(ModelId::WhisperLargeV3Turbo).artifact.file_name);
    let parakeet = models.join(model(ModelId::ParakeetTdt06BV3).artifact.file_name);
    fs::write(&turbo, b"tiny synthetic Turbo model").unwrap();
    fs::write(&parakeet, b"tiny synthetic Parakeet model").unwrap();

    let mut request = test_request(JobId(0xe201), Generation::first());
    request.source_sha256 = Some([0x31; 32]);
    request.source_samples = Some(16_000);
    request.model_path = parakeet.to_string_lossy().into_owned();
    request.model_sha256 = model(ModelId::ParakeetTdt06BV3)
        .artifact
        .sha256
        .as_bytes()
        .chunks_exact(2)
        .map(|pair| u8::from_str_radix(std::str::from_utf8(pair).unwrap(), 16).unwrap())
        .collect::<Vec<_>>()
        .try_into()
        .unwrap();
    request.destination = root.join("archive").to_string_lossy().into_owned();

    (ModelInspectionFixture(root), request, turbo, parakeet)
}

fn inspection_runtime(models: &Path, runtime_root: &Path) -> ImportRuntime {
    let worker = runtime_root.join("parakeet-runtime/worker.exe");
    let native = runtime_root.join("parakeet-runtime/native");
    fs::create_dir_all(worker.parent().unwrap()).unwrap();
    fs::create_dir_all(&native).unwrap();
    fs::write(&worker, b"synthetic worker placeholder").unwrap();
    let parakeet_paths = crate::parakeet_import::ParakeetWorkerPaths {
        executable: worker,
        native_dir: native,
        model: models.join(model(ModelId::ParakeetTdt06BV3).artifact.file_name),
        runtime_root: runtime_root.join("parakeet-runtime"),
    };
    ImportRuntime::new_with_catalog(
        WorkerPaths {
            cpu: models.join("missing-worker-cpu.exe"),
            gpu: models.join("missing-worker-gpu.exe"),
        },
        Arc::new(PublicationGate::default()),
        Some(RuntimeModelCatalog {
            catalog: crate::model_catalog::LocalModelCatalog::new(models),
            known_historical_turbo_path: r"C:\legacy\ggml-large-v3-turbo.bin".into(),
            parakeet_paths: Some(parakeet_paths),
            gpu_parakeet_paths: None,
        }),
    )
}

#[test]
fn queue_processing_inspects_only_its_required_model() {
    let (fixture, request, turbo, parakeet) = inspection_fixture("queue-inspection-scope");
    let mut queue = crate::queue_store::QueueStore::open(&request.destination).unwrap();
    queue.enqueue(request.clone()).unwrap();

    let mut runtime = inspection_runtime(&fixture.0.join("models"), &fixture.0);
    let result = runtime.process_queued(request, &mut VecDeque::new());

    assert!(result.is_err(), "the tiny registered-model fixture stays corrupt");
    assert_eq!(model_sha256_full_read_count(&turbo).unwrap(), 0);
    assert_eq!(model_sha256_full_read_count(&parakeet).unwrap(), 1);
}

#[test]
fn interrupted_recovery_inspects_only_its_required_model() {
    let (fixture, previous, turbo, parakeet) = inspection_fixture("recovery-inspection-scope");
    let mut queue = crate::queue_store::QueueStore::open(&previous.destination).unwrap();
    queue.enqueue(previous.clone()).unwrap();
    queue
        .set_status(
            previous.job_id,
            previous.generation,
            crate::queue_store::QueueStatus::Interrupted,
        )
        .unwrap();
    let mut resumed = previous.clone();
    resumed.generation = previous.generation.next().unwrap();

    let mut runtime = inspection_runtime(&fixture.0.join("models"), &fixture.0);
    let mut events = VecDeque::new();
    let _ = runtime.resume_interrupted(Box::new(previous), resumed, &mut events);

    assert_eq!(model_sha256_full_read_count(&turbo).unwrap(), 0);
    assert_eq!(model_sha256_full_read_count(&parakeet).unwrap(), 1);
    assert!(
        events.iter().any(|event| matches!(event, ImportEvent::Failed { message, .. } if message.contains("ModelHashMismatch"))),
        "the corrupt Parakeet model must retain its explicit integrity error: {events:?}"
    );
}
}
