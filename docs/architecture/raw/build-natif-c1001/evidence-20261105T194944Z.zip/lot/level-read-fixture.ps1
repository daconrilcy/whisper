$ErrorActionPreference='Stop'
. 'C:\wt\build-natif\ci\repro-native-compiler.ps1' -LibraryOnly
$root=Join-Path $script:Lot ('level-read-fixture-'+[guid]::NewGuid().ToString('N'))
New-Item -ItemType Directory -Path $root | Out-Null
$script:Journal=Join-Path $root 'journal.jsonl'
$script:LevelFile=Join-Path $root 'level.txt';$script:MonitorCsv=Join-Path $root 'sample.csv'
[IO.File]::WriteAllText($script:MonitorCsv,'fixture',$script:Utf8NoBom)
$script:Monitor=[Diagnostics.Process]::GetCurrentProcess();$script:MonitorCreated=$script:Monitor.StartTime.ToUniversalTime()
$script:MonitorHash=(Get-FileHash -LiteralPath C:/memwatch/MemWatch.ps1).Hash
function Get-WinEvent {return @()}
$ready=Join-Path $root 'writer-ready';$release=Join-Path $root 'release-writer'
$writer=Join-Path $root 'writer.ps1'
@'
param($Root)
$ErrorActionPreference='Stop'
$file=Join-Path $Root 'level.txt'
$stream=[IO.File]::Open($file,[IO.FileMode]::Create,[IO.FileAccess]::Write,[IO.FileShare]::ReadWrite)
try{
    [IO.File]::WriteAllText((Join-Path $Root 'writer-ready'),'open, truncated, not written')
    $until=[datetime]::UtcNow.AddSeconds(10)
    while(-not(Test-Path -LiteralPath (Join-Path $Root 'release-writer'))){if([datetime]::UtcNow -ge $until){throw 'Fixture release timed out'};Start-Sleep -Milliseconds 10}
    $bytes=[Text.Encoding]::UTF8.GetBytes('OK')
    $stream.Write($bytes);$stream.Flush($true)
}finally{$stream.Dispose()}
'@ | Set-Content -LiteralPath $writer -Encoding utf8NoBOM
$psi=[Diagnostics.ProcessStartInfo]::new((Get-Command pwsh.exe).Source);$psi.UseShellExecute=$false;$psi.CreateNoWindow=$true;$psi.RedirectStandardOutput=$true;$psi.RedirectStandardError=$true
foreach($arg in @('-NoProfile','-NonInteractive','-File',$writer,'-Root',$root)){$psi.ArgumentList.Add($arg)}
foreach($name in @('TEMP','TMP','LOCALAPPDATA','APPDATA','USERPROFILE','HOME')){$dir=Join-Path $root $name;New-Item -ItemType Directory -Path $dir | Out-Null;$psi.Environment[$name]=$dir}
$p=[Diagnostics.Process]::new();$p.StartInfo=$psi;$family=$null
try{
    if(-not $p.Start()){throw 'Fixture start failed'}
    $family=New-VoxPopuliProcessFamily $p;$stdout=$p.StandardOutput.ReadToEndAsync();$stderr=$p.StandardError.ReadToEndAsync()
    $until=[datetime]::UtcNow.AddSeconds(10)
    while(-not(Test-Path -LiteralPath $ready)){Update-VoxPopuliProcessFamily $family;if($p.HasExited -or [datetime]::UtcNow -ge $until){throw 'Fixture not ready'};Start-Sleep -Milliseconds 10}
    $handle=[IO.File]::Open($script:LevelFile,[IO.FileMode]::Open,[IO.FileAccess]::Read,[IO.FileShare]::ReadWrite)
    try{$reader=[IO.StreamReader]::new($handle);try{$raw=$reader.ReadToEnd()}finally{$reader.Dispose()}}finally{$handle.Dispose()}
    $failure=$null;try{$level=Get-ReproLevel}catch{$failure=$_.Exception.Message}
    [IO.File]::WriteAllText($release,'continue')
    if(-not $p.WaitForExit(10000)){throw 'Fixture writer did not exit'}
    if($p.ExitCode -ne 0){throw 'Fixture writer failed'}
    $after=Get-ReproLevel
    if($raw.Length -ne 0 -or $failure -cne 'Invalid MemWatch level.' -or $after -cne 'OK'){throw 'Hypothesis not reproduced by fixture'}
    @{confirmedInFixture=$true;rawDuringTruncation=$raw;rawLength=$raw.Length;readerError=$failure;levelAfterWrite=$after;realFailureCause='NOT PROVEN: real raw bytes were not recorded';root=$root;compilerStarted=$false} | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $root 'result.json') -Encoding utf8NoBOM
    "LEVEL_FIXTURE PASS root=$root emptyRead=0 oldReaderRefused=true after=OK compilerStarted=false"
}finally{
    if($null -ne $family){Stop-VoxPopuliProcessFamily $family;Close-VoxPopuliProcessFamily $family}
    foreach($s in @(@{task=$stdout;name='stdout.log'},@{task=$stderr;name='stderr.log'})){if($null -ne $s.task -and $s.task.Wait(10000)){[IO.File]::WriteAllText((Join-Path $root $s.name),$s.task.GetAwaiter().GetResult())}}
    $p.Dispose()
}
