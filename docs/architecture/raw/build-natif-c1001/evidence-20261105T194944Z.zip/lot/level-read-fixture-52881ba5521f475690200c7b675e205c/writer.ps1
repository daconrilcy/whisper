param($Root)
$ErrorActionPreference='Stop'
$file=Join-Path $Root 'level.txt'
$stream=[IO.File]::Open($file,[IO.FileMode]::Create,[IO.FileAccess]::Write,[IO.FileShare]::ReadWrite)
try{
    [IO.File]::WriteAllText((Join-Path $Root 'writer-ready'),'open, truncated, not written')
    $until=[datetime]::UtcNow.AddSeconds(10)
    while(-not(Test-Path -LiteralPath (Join-Path $Root 'release-writer'))){if([datetime]::UtcNow -ge $until){throw 'Fixture release timed out'};Start-Sleep -Milliseconds 10}
    $bytes=[Text.Encoding]::UTF8.GetBytes('OK')
    $stream.Write($bytes);$stream.Flush($true)
}finally{$stream.Dispose()}
