# C:\memwatch\MemWatch.ps1
# Mode Snapshot  : un relevé (tâche planifiée toutes les 10 min) -> memwatch.csv
# Mode Intensive : relevés toutes les N s jusqu'au fichier stop ou MaxMinutes -> intensive-<tag>-<date>.csv
#                  écrit aussi niveau-<tag>.txt (OK / ALERTE / STOP-LANCEMENTS / INTERROMPRE)
param(
  [ValidateSet('Snapshot','Intensive')] [string]$Mode = 'Snapshot',
  [int]$IntervalSeconds = 5,
  [int]$MaxMinutes = 240,
  [string]$Tag = 'manuel',
  [string]$OutDir = 'C:\memwatch'
)
$ErrorActionPreference = 'Stop'
New-Item -ItemType Directory $OutDir -Force | Out-Null
$start = Get-Date

function Get-Level([double]$pct) {
  if ($pct -ge 90) { 'INTERROMPRE' } elseif ($pct -ge 85) { 'STOP-LANCEMENTS' }
  elseif ($pct -ge 70) { 'ALERTE' } else { 'OK' }
}

function Get-Sample([bool]$withWhea) {
  $m  = Get-CimInstance Win32_PerfFormattedData_PerfOS_Memory
  $ps = Get-Process
  $cl = @($ps | Where-Object ProcessName -eq 'cl')
  $pct = [math]::Round(100 * $m.CommittedBytes / $m.CommitLimit, 1)
  $whea = ''
  if ($withWhea) {
    $whea = @(Get-WinEvent -FilterHashtable @{LogName='System'; ProviderName='Microsoft-Windows-WHEA-Logger'; StartTime=$start} -ErrorAction SilentlyContinue).Count
  }
  [pscustomobject]@{
    Heure          = (Get-Date).ToString('yyyy-MM-dd HH:mm:ss')
    Tag            = $Tag
    ValideeGo      = [math]::Round($m.CommittedBytes/1GB, 2)
    LimiteGo       = [math]::Round($m.CommitLimit/1GB, 2)
    Pct            = $pct
    Niveau         = Get-Level $pct
    DispoGo        = [math]::Round($m.AvailableBytes/1GB, 2)
    PagineGo       = [math]::Round($m.PoolPagedBytes/1GB, 2)
    NonPagineGo    = [math]::Round($m.PoolNonpagedBytes/1GB, 2)
    PriveProcGo    = [math]::Round(($ps | Measure-Object PrivateMemorySize64 -Sum).Sum/1GB, 2)
    Processus      = $ps.Count
    Handles        = ($ps | Measure-Object HandleCount -Sum).Sum
    ClNombre       = $cl.Count
    ClPriveGo      = [math]::Round(($cl | Measure-Object PrivateMemorySize64 -Sum).Sum/1GB, 2)
    WheaDepuisDebut= $whea
    TopHandles     = ($ps | Sort-Object HandleCount -Descending | Select-Object -First 5 |
                       ForEach-Object { "{0}:{1}" -f $_.ProcessName, $_.HandleCount }) -join ' '
    TopNombre      = ($ps | Group-Object ProcessName | Sort-Object Count -Descending | Select-Object -First 8 |
                       ForEach-Object { "{0}:{1}" -f $_.Name, $_.Count }) -join ' '
  }
}

if ($Mode -eq 'Snapshot') {
  Get-Sample $true | Export-Csv (Join-Path $OutDir 'memwatch.csv') -Append -NoTypeInformation -Encoding UTF8
  return
}

# Mode Intensive
$csv  = Join-Path $OutDir ("intensive-{0}-{1}.csv" -f $Tag, $start.ToString('yyyyMMdd-HHmmss'))
$stop = Join-Path $OutDir "stop-$Tag"
$lvl  = Join-Path $OutDir "niveau-$Tag.txt"
Remove-Item $stop -ErrorAction SilentlyContinue
$i = 0
while (-not (Test-Path $stop) -and ((Get-Date) - $start).TotalMinutes -lt $MaxMinutes) {
  $s = Get-Sample (($i % 12) -eq 0)      # WHEA vérifié environ toutes les minutes
  $s | Export-Csv $csv -Append -NoTypeInformation -Encoding UTF8
  Set-Content $lvl $s.Niveau -Encoding UTF8
  $i++
  Start-Sleep -Seconds $IntervalSeconds
}
Set-Content $lvl 'TERMINE' -Encoding UTF8