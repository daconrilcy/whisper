param($Level,$Ready)
$stream=[IO.File]::Open($Level,[IO.FileMode]::Create,[IO.FileAccess]::Write,[IO.FileShare]::ReadWrite)
try{
    [IO.File]::WriteAllText($Ready,'ready')
    Start-Sleep -Milliseconds 150
    $bytes=[Text.Encoding]::UTF8.GetBytes('OK');$stream.Write($bytes);$stream.Flush($true)
}finally{$stream.Dispose()}
