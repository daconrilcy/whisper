param($Root,$Go)
[IO.File]::WriteAllText((Join-Path $Root 'ready'),'ready')
$until=[datetime]::UtcNow.AddSeconds(10)
while(-not(Test-Path -LiteralPath $Go)){if([datetime]::UtcNow -ge $until){throw 'No release'};Start-Sleep -Milliseconds 5}
$begin=[datetimeoffset]::UtcNow
Start-Sleep -Milliseconds 400
@{pid=$PID;startedUtc=$begin;exitedUtc=[datetimeoffset]::UtcNow}|ConvertTo-Json|Set-Content -LiteralPath (Join-Path $Root 'lifetime.json') -Encoding utf8NoBOM
