# Lot-local supervision of the existing public native build entry point.
# Operator prerequisites, not enforced by this recipe: qualified A/B1 stress,
# reviewed/tested cache candidate, and remaining lot time/quota. cpu3 is only
# the permitted compiler-crash retry, never an extra unconditional build.
[CmdletBinding()]
param([Parameter(Mandatory)][ValidateSet('cpu1','cpu2','cpu3','gpu1','gpu2')][string]$Build)
$ErrorActionPreference='Stop'
. 'C:\wt\build-natif\ci\repro-native-compiler.ps1' -LibraryOnly
$variant=$Build.Substring(0,3);$buildId='C1001-'+$Build
# All supervisor journals must stay inside the native guard's existing allowed lot.
$root=Join-Path $script:Repo "target/native-build/supervision/$buildId"
Assert-NoReparseChain $root 'native supervision root'
if(Test-Path -LiteralPath $root){throw 'Native supervision identifier already attempted.'}
New-Item -ItemType Directory -Path $root | Out-Null
$script:Journal=Join-Path $root 'journal.jsonl';$script:Watch=$null
$script:Monitor=$null;$script:MonitorCsv=$null;$script:MonitorHash=(Get-FileHash -LiteralPath C:/memwatch/MemWatch.ps1).Hash
$tag=$buildId;$script:LevelFile="C:\memwatch\niveau-$tag.txt";$stop="C:\memwatch\stop-$tag"
$process=$null;$family=$null;$outTask=$null;$errTask=$null;$monitorOut=$null;$monitorErr=$null;$monitorStarted=$false;$processStarted=$false;$primary=$null
try{
    Assert-ReproWer;Assert-ReproPrecondition
    foreach($file in @($script:LevelFile,$stop)){if(Test-Path -LiteralPath $file){throw 'Native MemWatch tag already exists.'}}
    if(@(Get-ChildItem C:/memwatch -File -Filter "intensive-$tag-*.csv").Count){throw 'Native monitor CSV tag already exists.'}
    $temp=Join-Path $root 'temp';New-Item -ItemType Directory -Path $temp | Out-Null
    $psi=[Diagnostics.ProcessStartInfo]::new((Join-Path $PSHOME 'pwsh.exe'));$psi.UseShellExecute=$false;$psi.CreateNoWindow=$true;$psi.RedirectStandardOutput=$true;$psi.RedirectStandardError=$true
    foreach($arg in @('-NoProfile','-NonInteractive','-File','C:\memwatch\MemWatch.ps1','-Mode','Intensive','-Tag',$tag,'-IntervalSeconds','5')){$psi.ArgumentList.Add($arg)}
    $psi.Environment['TEMP']=$temp;$psi.Environment['TMP']=$temp
    $script:Monitor=[Diagnostics.Process]::new();$script:Monitor.StartInfo=$psi
    Write-ReproRecord 'MEMWATCH_LAUNCH' @{tag=$tag;scriptSha256=$script:MonitorHash}
    if(-not $script:Monitor.Start()){throw 'Native monitor did not start.'};$monitorStarted=$true;$script:MonitorCreated=$script:Monitor.StartTime.ToUniversalTime()
    $monitorOut=$script:Monitor.StandardOutput.ReadToEndAsync();$monitorErr=$script:Monitor.StandardError.ReadToEndAsync()
    $until=[datetimeoffset]::UtcNow.AddSeconds(20)
    while(-not(Test-Path -LiteralPath $script:LevelFile)){if($script:Monitor.HasExited -or [datetimeoffset]::UtcNow -ge $until){throw 'Native monitor not ready.'};Start-Sleep -Milliseconds 100}
    $csv=@(Get-ChildItem C:/memwatch -File -Filter "intensive-$tag-*.csv");if($csv.Count -ne 1){throw 'Native CSV identity ambiguous.'};$script:MonitorCsv=$csv[0].FullName
    while((Get-ReproLevel) -eq 'STOP-LANCEMENTS'){Start-Sleep -Milliseconds 100}
    $psi=[Diagnostics.ProcessStartInfo]::new((Join-Path $PSHOME 'pwsh.exe'));$psi.UseShellExecute=$false;$psi.CreateNoWindow=$true;$psi.RedirectStandardOutput=$true;$psi.RedirectStandardError=$true;$psi.WorkingDirectory=$script:Repo
    foreach($arg in @('-NoProfile','-NonInteractive','-File',(Join-Path $script:Repo 'ci/build-native.ps1'),'-Variant',$variant,'-BuildId',$buildId)){$psi.ArgumentList.Add($arg)}
    # Preserve the real USERPROFILE/LOCALAPPDATA for the guard's protected watcher roots.
    # The existing guard clears/isolates the actual build child environment itself.
    $psi.Environment['TEMP']=$temp;$psi.Environment['TMP']=$temp
    $process=[Diagnostics.Process]::new();$process.StartInfo=$psi
    while((Get-ReproLevel) -eq 'STOP-LANCEMENTS'){Start-Sleep -Milliseconds 100}
    Write-ReproRecord 'NATIVE_LAUNCH' @{buildId=$buildId;variant=$variant;executable=$psi.FileName;arguments=@($psi.ArgumentList);sourceSha256=(Get-FileHash -LiteralPath (Join-Path $script:Repo 'ci/build-native.ps1')).Hash;monitorCsv=$script:MonitorCsv}
    if(-not $process.Start()){throw 'Public native entry point did not start.'};$processStarted=$true
    $family=New-VoxPopuliProcessFamily $process;$outTask=$process.StandardOutput.ReadToEndAsync();$errTask=$process.StandardError.ReadToEndAsync()
    while(-not $process.HasExited){Update-VoxPopuliProcessFamily $family;[void](Get-ReproLevel);Start-Sleep -Milliseconds 100}
    $process.WaitForExit();$exit=$process.ExitCode
    Write-ReproRecord 'NATIVE_FINISH' @{buildId=$buildId;pid=$process.Id;exit=$exit}
    if($exit -ne 0){throw "Native build failed, exit $exit. No automatic retry."}
}catch{$primary=$_;Write-ReproRecord 'STOP' @{failure=$_.Exception.Message};throw}
finally{
    $errors=[Collections.Generic.List[string]]::new()
    try{if($null -ne $family){Stop-VoxPopuliProcessFamily $family}elseif($processStarted -and -not $process.HasExited){$process.Kill($true);if(-not $process.WaitForExit(10000)){throw 'Owned native root survived.'}}}catch{$errors.Add($_.Exception.Message)}
    foreach($stream in @(@{task=$outTask;name='stdout.log'},@{task=$errTask;name='stderr.log'})){
        try{$text=if($null -eq $stream.task){'PROCESS_NOT_STARTED'}elseif($stream.task.Wait(10000)){$stream.task.GetAwaiter().GetResult()}else{'CAPTURE_INCOMPLETE'};[IO.File]::WriteAllText((Join-Path $root $stream.name),$text,$script:Utf8NoBom);if($text -ceq 'CAPTURE_INCOMPLETE'){throw 'Native stream still open.'}}catch{$errors.Add($_.Exception.Message)}
    }
    try{Close-VoxPopuliProcessFamily $family}catch{$errors.Add($_.Exception.Message)}
    try{if($null -ne $process){$process.Dispose()}}catch{$errors.Add($_.Exception.Message)}
    if($monitorStarted){
        try{if(-not $script:Monitor.HasExited){[IO.File]::WriteAllText($stop,'stop',$script:Utf8NoBom);if(-not $script:Monitor.WaitForExit(20000)){throw 'Native monitor did not stop.'}}}catch{$errors.Add($_.Exception.Message)}
        foreach($stream in @(@{task=$monitorOut;name='memwatch.stdout.log'},@{task=$monitorErr;name='memwatch.stderr.log'})){try{if(-not $stream.task.Wait(10000)){throw 'Monitor output still open.'};[IO.File]::WriteAllText((Join-Path $root $stream.name),$stream.task.GetAwaiter().GetResult(),$script:Utf8NoBom)}catch{$errors.Add($_.Exception.Message)}}
        try{$script:Monitor.Dispose()}catch{$errors.Add($_.Exception.Message)}
    }
    Write-ReproRecord 'CLOSED' @{cleanupErrors=$errors.ToArray()}
    if($errors.Count -and $null -eq $primary){throw ($errors -join '; ')}
}
