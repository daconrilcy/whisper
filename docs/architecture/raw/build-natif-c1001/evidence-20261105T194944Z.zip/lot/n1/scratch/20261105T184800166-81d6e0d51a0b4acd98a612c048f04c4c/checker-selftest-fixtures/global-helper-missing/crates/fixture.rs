#[test]
fn calls_helper() { let _ = root(); }
fn root() -> std::path::PathBuf { std::env::var_os("REQUIRED_ROOT").unwrap().into() }
