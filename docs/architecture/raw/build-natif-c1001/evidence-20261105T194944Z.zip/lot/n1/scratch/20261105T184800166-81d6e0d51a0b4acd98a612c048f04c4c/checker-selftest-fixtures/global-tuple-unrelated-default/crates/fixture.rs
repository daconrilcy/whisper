#[test]
fn calls_helper() {
let pair = (std::env::var_os("REQUIRED").expect("required"), other.unwrap_or_else(|| std::env::temp_dir()));
drop(pair);
}
