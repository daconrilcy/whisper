#[test]
fn calls_helper() { let _ = root(); }
fn root() -> std::path::PathBuf { std::env::var_os("REQUIRED_ROOT").map(std::path::PathBuf::from).unwrap_or_else(|| std::env::temp_dir()) }
