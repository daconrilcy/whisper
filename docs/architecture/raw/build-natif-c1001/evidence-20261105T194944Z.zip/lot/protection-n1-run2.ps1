# Lot-local execution recipe: only existing N1 guard commands, supervised by unchanged MemWatch.
$ErrorActionPreference='Stop'
$PSNativeCommandUseErrorActionPreference=$false
$repo='C:\wt\build-natif'
$lot=Join-Path $repo 'target/build-natif-c1001/protection-run2'
$pwsh=(Get-Command pwsh.exe).Source
$toolchain='C:\Users\cyril\.rustup\toolchains\1.98.1-x86_64-pc-windows-msvc\bin'
foreach($exe in @('cargo.exe','rustc.exe','rustdoc.exe')){if(-not(Test-Path -LiteralPath (Join-Path $toolchain $exe))){throw 'Installed pinned Rust toolchain missing.'}}
if([IO.File]::ReadAllText((Join-Path $repo 'rust-toolchain.toml')) -notmatch 'channel\s*=\s*"1\.98\.1"'){throw 'Rust channel differs from the selected installed toolchain.'}
$tag='C1001-protection-run2'
$monitorScript='C:\memwatch\MemWatch.ps1'
$levelFile="C:\memwatch\niveau-$tag.txt"
$stopFile="C:\memwatch\stop-$tag"
$start=[DateTimeOffset]::Parse('2026-11-05T16:54:46Z')
$deadline=[DateTimeOffset]::Parse('2026-11-05T21:54:46Z')
$journal=Join-Path $lot 'journal.jsonl'
$utf8=[Text.UTF8Encoding]::new($false)
$results=[Collections.Generic.List[object]]::new()
$monitor=$null;$monitorOut=$null;$monitorErr=$null
$monitorIdentity=$null;$monitorCsv=$null;$n1RetryUsed=$false
$monitorStarted=$false
$monitorHash=(Get-FileHash -LiteralPath $monitorScript -Algorithm SHA256).Hash
$ast=[Management.Automation.Language.Parser]::ParseFile((Join-Path $repo 'ci/guard-native.ps1'),[ref]$null,[ref]$null)
foreach($name in @('New-VoxPopuliProcessFamily','Assert-VoxPopuliCleanupDeadline','Update-VoxPopuliProcessFamily','Stop-VoxPopuliKnownProcesses','Stop-VoxPopuliProcessFamily','Close-VoxPopuliProcessFamily')){
    $f=@($ast.EndBlock.Statements | Where-Object {$_ -is [Management.Automation.Language.FunctionDefinitionAst] -and $_.Name -ceq $name})
    if($f.Count -ne 1){throw "Missing existing process helper $name"}
    . ([scriptblock]::Create($f[0].Extent.Text.Replace("function $name(","function script:${name}(")))
}
function Log([string]$Event,$Data){
    [IO.File]::AppendAllText($journal,((@{utc=[DateTimeOffset]::UtcNow.ToString('o');event=$Event;data=$Data}|ConvertTo-Json -Depth 9 -Compress)+[Environment]::NewLine),$utf8)
}
function Whea {
    try{return @(Get-WinEvent -FilterHashtable @{LogName='System';ProviderName='Microsoft-Windows-WHEA-Logger';StartTime=$start.LocalDateTime} -ErrorAction Stop)}
    catch{if($_.FullyQualifiedErrorId -like 'NoMatchingEventsFound*'){return @()};throw}
}
function Check-Level {
    if([DateTimeOffset]::UtcNow -ge $deadline){throw 'Lot time budget exhausted.'}
    $w=@(Whea);if($w.Count){Log 'WHEA' $w;throw 'MATERIEL A REVERIFIER'}
    if($null -eq $monitor -or $monitor.HasExited){throw 'MemWatch is not running.'}
    if($null -eq $monitorIdentity -or $monitor.Id -ne $monitorIdentity.pid -or [math]::Abs(($monitor.StartTime.ToUniversalTime()-$monitorIdentity.createdUtc).TotalMilliseconds) -gt 1){throw 'MemWatch process identity changed.'}
    if((Get-FileHash -LiteralPath $monitorScript -Algorithm SHA256).Hash -cne $monitorHash){throw 'MemWatch changed during the lot.'}
    $item=Get-Item -LiteralPath $levelFile -ErrorAction Stop
    if(([datetime]::UtcNow-$item.LastWriteTimeUtc).TotalSeconds -gt 20){throw 'MemWatch level is stale.'}
    if(-not $monitorCsv -or -not(Test-Path -LiteralPath $monitorCsv)){throw 'MemWatch Intensive CSV is missing.'}
    if(([datetime]::UtcNow-(Get-Item -LiteralPath $monitorCsv).LastWriteTimeUtc).TotalSeconds -gt 20){throw 'MemWatch Intensive CSV is stale.'}
    $stream=[IO.File]::Open($levelFile,[IO.FileMode]::Open,[IO.FileAccess]::Read,[IO.FileShare]::ReadWrite)
    try{$reader=[IO.StreamReader]::new($stream);try{$level=$reader.ReadToEnd().Trim().Trim([char]0xfeff)}finally{$reader.Dispose()}}finally{$stream.Dispose()}
    if($level -notin @('OK','ALERTE','STOP-LANCEMENTS','INTERROMPRE')){throw "Invalid MemWatch level $level"}
    if($level -eq 'INTERROMPRE'){
        $p=@(Get-CimInstance Win32_Process | Sort-Object PrivatePageCount -Descending | Select-Object -First 15 Name,ProcessId,ParentProcessId,PrivatePageCount)
        Log 'MEMORY_INTERRUPT' $p;throw 'INTERROMPRE: memory >=90%'
    }
    if($level -eq 'ALERTE'){Log 'MEMORY_ALERT' @{level=$level}}
    return $level
}
function Isolate-Host($psi,[string]$Name){
    foreach($variable in @('TEMP','TMP','LOCALAPPDATA','APPDATA','USERPROFILE','HOME')){
        $path=Join-Path $lot "host-env/$Name/$variable"
        New-Item -ItemType Directory -Path $path -Force | Out-Null
        $psi.Environment[$variable]=$path
    }
    $psi.Environment['PATH']=$toolchain+';'+$psi.Environment['PATH']
    $psi.Environment['RUSTC']=Join-Path $toolchain 'rustc.exe'
    $psi.Environment['RUSTDOC']=Join-Path $toolchain 'rustdoc.exe'
}
function Run-Owned([string]$Label,[string]$Work,[string[]]$Arguments){
    while((Check-Level) -eq 'STOP-LANCEMENTS'){Log 'PAUSE_LAUNCH' @{label=$Label};Start-Sleep -Seconds 2}
    if((Get-PSDrive C).Free -lt 30GB){throw 'Less than 30 GiB free.'}
    $psi=[Diagnostics.ProcessStartInfo]::new($pwsh);$psi.UseShellExecute=$false;$psi.CreateNoWindow=$true
    $psi.RedirectStandardOutput=$true;$psi.RedirectStandardError=$true;$psi.WorkingDirectory=$Work
    foreach($arg in @('-NoLogo','-NoProfile','-NonInteractive')+$Arguments){$psi.ArgumentList.Add($arg)}
    Isolate-Host $psi $Label
    $process=[Diagnostics.Process]::new();$process.StartInfo=$psi
    $family=$null;$stdout=$null;$stderr=$null;$record=[ordered]@{label=$Label;work=$Work;arguments=$Arguments;startedUtc=[DateTimeOffset]::UtcNow.ToString('o');exit=$null;stdout=(Join-Path $lot "$Label.stdout.log");stderr=(Join-Path $lot "$Label.stderr.log");monitorPid=$monitorIdentity.pid;monitorCreatedUtc=$monitorIdentity.createdUtc.ToString('o');monitorCsv=$monitorCsv;levelBeforeLaunch=(Check-Level)}
    while($record.levelBeforeLaunch -eq 'STOP-LANCEMENTS'){Log 'PAUSE_LAUNCH' @{label=$Label};Start-Sleep -Seconds 2;$record.levelBeforeLaunch=Check-Level}
    Log 'LAUNCH' $record
    try{
        if(-not $process.Start()){throw 'Process did not start.'}
        $family=New-VoxPopuliProcessFamily $process
        $stdout=$process.StandardOutput.ReadToEndAsync();$stderr=$process.StandardError.ReadToEndAsync()
        do{
            Update-VoxPopuliProcessFamily $family
            [void](Check-Level)
            if($process.HasExited){break};Start-Sleep -Milliseconds 500
        }while($true)
        $process.WaitForExit();$record.exit=$process.ExitCode
        if(-not $stdout.Wait(10000) -or -not $stderr.Wait(10000)){throw 'Process streams did not close.'}
        Stop-VoxPopuliProcessFamily $family
        return [pscustomobject]$record
    }catch{
        $record.failure=$_.Exception.Message
        if($null -ne $family){try{Stop-VoxPopuliProcessFamily $family}catch{$record.stopFailure=$_.Exception.Message}}
        throw
    }finally{
        $cleanup=[Collections.Generic.List[string]]::new()
        foreach($stream in @(@{task=$stdout;path=$record.stdout},@{task=$stderr;path=$record.stderr})){
            try{
                $text=if($null -eq $stream.task){'PROCESS_NOT_STARTED'}elseif($stream.task.Wait(10000)){$stream.task.GetAwaiter().GetResult()}else{'CAPTURE_INCOMPLETE: stream still open after owned process cleanup.'}
                [IO.File]::WriteAllText($stream.path,$text,$utf8)
                if($text -like 'CAPTURE_INCOMPLETE:*'){$cleanup.Add($text)}
            }catch{$cleanup.Add('Output preservation: '+$_.Exception.Message)}
        }
        try{if($null -ne $family){Close-VoxPopuliProcessFamily $family}}catch{$cleanup.Add($_.Exception.Message)}
        try{$process.Dispose()}catch{$cleanup.Add($_.Exception.Message)}
        if($cleanup.Count){$record.cleanupFailures=$cleanup.ToArray()}
        $record.finishedUtc=[DateTimeOffset]::UtcNow.ToString('o');Log 'FINISH' $record
        if($cleanup.Count -and -not $record.Contains('failure')){throw "Cleanup failed: $($cleanup -join '; ')"}
    }
}
function Guard([string]$Side,[string]$Work,[string]$Label,[string[]]$Cargo=@(),[string]$Mode='Run'){
    function Quote([string]$Text){return "'"+$Text.Replace("'","''")+"'"}
    $command='& '+(Quote (Join-Path $Work 'ci/guard-level1.ps1'))+' -Mode '+(Quote $Mode)+" -LotRoot 'target/build-natif-c1001/n1'"
    if($Cargo.Count){$command+=' -CargoArgsJson '+(Quote (ConvertTo-Json -InputObject $Cargo -Compress))}
    # Existing guard clears Whisper/Parakeet and accepts explicit CUDA/GGML removals.
    $clear=@(Get-ChildItem Env: | Where-Object Name -Match '^(CUDA_PATH($|_V)|GGML_)' | Select-Object -ExpandProperty Name)
    if($clear.Count){$command+=' -UnsetEnv @('+(@($clear|ForEach-Object {Quote $_}) -join ',')+')'}
    Log 'N1_COMMAND' @{label="$Side-$Label";command=$command}
    $encoded=[Convert]::ToBase64String([Text.Encoding]::Unicode.GetBytes($command))
    return Run-Owned "$Side-$Label" $Work @('-EncodedCommand',$encoded)
}
function Require-Pass($Result){$results.Add($Result);if($Result.exit -ne 0){throw "N1 preparation failed: $($Result.label)"}}
function Cargo-Logs($Result){
    $raw=[IO.File]::ReadAllText($Result.stdout)
    $match=[regex]::Match($raw,'(?m)^N1_GUARD .+ stdout=(.+) stderr=(.+)\r?$')
    if(-not $match.Success){throw "Missing N1 guard output paths for $($Result.label)"}
    return @{stdout=$match.Groups[1].Value.Trim();stderr=$match.Groups[2].Value.Trim()}
}
try{
    if(Test-Path -LiteralPath $stopFile){throw 'Monitor tag already has a stop file.'}
    if(Test-Path -LiteralPath $levelFile){throw 'Monitor tag already exists.'}
    if(@(Get-ChildItem C:/memwatch -File -Filter "intensive-$tag-*.csv").Count){throw 'Monitor CSV tag already exists.'}
    $psi=[Diagnostics.ProcessStartInfo]::new($pwsh);$psi.UseShellExecute=$false;$psi.CreateNoWindow=$true
    $psi.RedirectStandardOutput=$true;$psi.RedirectStandardError=$true;$psi.WorkingDirectory=$lot
    foreach($arg in @('-NoLogo','-NoProfile','-NonInteractive','-File',$monitorScript,'-Mode','Intensive','-Tag',$tag,'-IntervalSeconds','5')){$psi.ArgumentList.Add($arg)}
    Isolate-Host $psi 'memwatch'
    $monitor=[Diagnostics.Process]::new();$monitor.StartInfo=$psi
    Log 'MEMWATCH_LAUNCH' @{tag=$tag;scriptSha256=$monitorHash}
    if(-not $monitor.Start()){throw 'MemWatch did not start.'}
    $monitorStarted=$true
    $monitorIdentity=@{pid=$monitor.Id;createdUtc=$monitor.StartTime.ToUniversalTime()}
    $monitorOut=$monitor.StandardOutput.ReadToEndAsync();$monitorErr=$monitor.StandardError.ReadToEndAsync()
    $wait=[DateTimeOffset]::UtcNow.AddSeconds(20)
    while(-not(Test-Path -LiteralPath $levelFile)){if($monitor.HasExited -or [DateTimeOffset]::UtcNow -ge $wait){throw 'MemWatch produced no level.'};Start-Sleep -Milliseconds 200}
    $csvs=@(Get-ChildItem C:/memwatch -File -Filter "intensive-$tag-*.csv")
    if($csvs.Count -ne 1){throw 'MemWatch CSV identity is ambiguous.'}
    $monitorCsv=$csvs[0].FullName
    Log 'MEMWATCH_READY' @{pid=$monitorIdentity.pid;createdUtc=$monitorIdentity.createdUtc.ToString('o');csv=$monitorCsv;toolchain=$toolchain}
    [void](Check-Level)
    foreach($side in @('main','candidate')){
        $work=if($side -eq 'main'){'C:\dev\whisper'}else{$repo}
        Require-Pass (Guard $side $work 'selftest' @() 'SelfTest')
        Require-Pass (Guard $side $work 'structure' @() 'Structure')
        if(-not(Test-Path -LiteralPath (Join-Path $work 'target/cargo-home-shared/registry/src'))){Require-Pass (Guard $side $work 'fetch' @('fetch','--locked'))}
        foreach($selection in @(@{id='default';package=$null},@{id='cpu';package='whisper-worker-cpu';kind='Cpu'},@{id='parakeet';package='whisper-worker-parakeet-cpu';kind='ParakeetCpu'},@{id='common';package='whisper-worker-common';kind='Cpu'})){
            $tokens=@('test');if($selection.package){$tokens+=@('-p',$selection.package)}
            if($selection.package){
                $built=Guard $side $work ($selection.id+'-compile') ($tokens+@('--no-run'));Require-Pass $built
                $logs=Cargo-Logs $built;$text=[IO.File]::ReadAllText($logs.stderr)
                $harnesses=@([regex]::Matches($text,'\(([^()\r\n]+\.exe)\)') | ForEach-Object {$_.Groups[1].Value} | Sort-Object -Unique)
                if(-not $harnesses.Count){throw "No worker harness from Cargo: $($selection.id)"}
                foreach($h in $harnesses){Require-Pass (Run-Owned "$side-$($selection.id)-pe" $work @('-File',(Join-Path $work 'ci/check-worker-imports.ps1'),'-Kind',$selection.kind,'-Path',$h))}
            }
            $listed=Guard $side $work ($selection.id+'-list') ($tokens+@('--','--list'));Require-Pass $listed
            $run=Guard $side $work ($selection.id+'-tests') $tokens;$results.Add($run)
            if($run.exit -ne 0){
                Log 'N1_FIRST_FAILURE' $run
                if($n1RetryUsed){throw 'Global N1 retry already consumed.'}
                $n1RetryUsed=$true
                $again=Guard $side $work ($selection.id+'-tests-retry') $tokens;$results.Add($again)
                if($again.exit -ne 0){throw "N1 failure reproduced: $side $($selection.id)"}
                Log 'INSTABILITE_POSSIBLE' @{first=$run.label;retry=$again.label}
            }
        }
    }
    $results | ConvertTo-Json -Depth 8 | Set-Content (Join-Path $lot 'protection-n1-results.json') -Encoding utf8NoBOM
    'N1 RUNS FINISHED; compare actual Cargo logs before issuing a parity verdict.'
}finally{
    if($null -ne $monitor -and $monitorStarted){
        if(-not $monitor.HasExited){[IO.File]::WriteAllText($stopFile,'stop',$utf8);if(-not $monitor.WaitForExit(20000)){throw 'MemWatch did not stop after its stop file.'}}
        if($null -ne $monitorOut){[IO.File]::WriteAllText((Join-Path $lot 'memwatch.stdout.log'),$monitorOut.GetAwaiter().GetResult(),$utf8)}
        if($null -ne $monitorErr){[IO.File]::WriteAllText((Join-Path $lot 'memwatch.stderr.log'),$monitorErr.GetAwaiter().GetResult(),$utf8)}
        Log 'MEMWATCH_END' @{tag=$tag;pid=$monitor.Id;exit=$monitor.ExitCode};$monitor.Dispose()
    }
    $results | ConvertTo-Json -Depth 8 | Set-Content (Join-Path $lot 'protection-n1-results-partial.json') -Encoding utf8NoBOM
}
