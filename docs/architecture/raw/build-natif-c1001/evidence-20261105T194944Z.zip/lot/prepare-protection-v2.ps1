$ErrorActionPreference='Stop'
$repo='C:\wt\build-natif'
$lot=Join-Path $repo 'target/build-natif-c1001'
$reference='refs/heads/codex/build-natif-protection-c1001-v2'
& git.exe --no-optional-locks -C $repo show-ref --verify --quiet $reference
if($LASTEXITCODE -eq 0){throw 'Protection proposal ref exists; nothing overwritten.'}
$paths=@('AGENTS.md','ci/build-native.ps1','ci/guard-native.ps1','ci/native-build-control.cs','ci/native-directory-watch.cs','ci/native-profiles.json','ci/native-workspace.ps1','ci/test-native-build-control.cs','ci/test-native-build-control.ps1','ci/test-native-build-flags.ps1','ci/test-native-directory-watch.ps1','ci/test-native-workspace.ps1','native/.gitignore','native/build-config.json','native/patches/ggml-pinned-build-commit.patch','native/runtime-pins/reference.json','docs/architecture/raw/native-build/installed-inventory.json','docs/architecture/NATIVE-BUILD.md')
$index=Join-Path $lot 'protection-v2.index'
if(Test-Path -LiteralPath $index){throw 'Proposal index exists.'}
$oldIndex=$env:GIT_INDEX_FILE
$source=(& git.exe --no-optional-locks -C $repo rev-parse HEAD).Trim()
$parent=(& git.exe --no-optional-locks -C $repo rev-parse main).Trim()
try{
    $env:GIT_INDEX_FILE=$index
    & git.exe --no-optional-locks -C $repo read-tree $parent
    if($LASTEXITCODE -ne 0){throw 'Cannot initialize proposal index.'}
    foreach($path in $paths){
        $line=(& git.exe --no-optional-locks -C $repo ls-tree $source -- $path)
        if($LASTEXITCODE -ne 0 -or $line -notmatch '^(100644) blob ([0-9a-f]{40})\t'){throw "Missing source blob $path"}
        $mode=$matches[1];$hash=$matches[2]
        if($path -eq 'docs/architecture/NATIVE-BUILD.md'){
            $hash=(& git.exe --no-optional-locks -C $repo hash-object -w --path=$path -- (Join-Path $lot 'protection/NATIVE-BUILD.md')).Trim()
            if($LASTEXITCODE -ne 0){throw 'Cannot write documentation blob.'}
        }
        & git.exe --no-optional-locks -C $repo update-index --add --cacheinfo "$mode,$hash,$path"
        if($LASTEXITCODE -ne 0){throw "Cannot stage proposal blob $path"}
    }
    $tree=(& git.exe --no-optional-locks -C $repo write-tree).Trim()
    if($LASTEXITCODE -ne 0){throw 'Cannot write proposal tree.'}
    $commit=(& git.exe --no-optional-locks -C $repo commit-tree $tree -p $parent -m 'native: proteger la chaine de compilation non qualifiee').Trim()
    if($LASTEXITCODE -ne 0){throw 'Cannot create reviewable protection commit.'}
    & git.exe --no-optional-locks -C $repo update-ref $reference $commit ('0'*40)
    if($LASTEXITCODE -ne 0){throw 'Cannot create proposal reference.'}
    $changed=@(& git.exe --no-optional-locks -C $repo diff --name-only $parent $commit)
    $allBranch=@(& git.exe --no-optional-locks -C $repo diff --name-only $parent $source)
    $excluded=@($allBranch | Where-Object {$_ -notin $changed})
    $rust=@(& git.exe --no-optional-locks -C $repo diff --name-only $parent $commit -- crates Cargo.toml Cargo.lock rust-toolchain.toml)
    if($rust.Count){throw 'Proposal modifies Rust/Cargo/toolchain.'}
    [ordered]@{source=$source;parent=$parent;commit=$commit;reference=$reference;included=$changed;excluded=$excluded;rustCargoDelta=$rust;mergeExecuted=$false;mergeCommand='git -C C:/dev/whisper merge --no-ff codex/build-natif-protection-c1001'} | ConvertTo-Json -Depth 8 | Set-Content (Join-Path $lot 'protection-proposal-v2.json') -Encoding utf8NoBOM
    & git.exe --no-optional-locks -C $repo diff --stat $parent $commit
    "PROPOSAL $reference $commit; NOT MERGED"
}finally{[Environment]::SetEnvironmentVariable('GIT_INDEX_FILE',$oldIndex,'Process')}
