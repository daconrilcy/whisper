# Retention only after the WHEA stop. No compilation, test, cleanup or registry mutation.
$ErrorActionPreference='Stop'
$repo='C:\wt\build-natif';$lot=Join-Path $repo 'target/build-natif-c1001'
. (Join-Path $repo 'ci/native-workspace.ps1')
$stamp=[datetime]::UtcNow.ToString('yyyyMMddTHHmmssZ')
$outDir=Join-Path $repo 'docs/architecture/raw/build-natif-c1001'
$zipPath=Join-Path $outDir ("evidence-$stamp.zip")
$retention=Join-Path $lot ('retention-'+$stamp)
foreach($path in @($outDir,$retention)){
    $cursor=$path
    while($cursor){if((Test-Path -LiteralPath $cursor) -and ((Get-Item -LiteralPath $cursor -Force).Attributes -band [IO.FileAttributes]::ReparsePoint)){throw 'Retention root crosses a link.'};$cursor=Split-Path $cursor -Parent}
}
if(Test-Path -LiteralPath $retention){throw 'Retention root exists.'}
New-Item -ItemType Directory -Path $retention | Out-Null
if(-not(Test-Path -LiteralPath $outDir)){New-Item -ItemType Directory -Path $outDir | Out-Null}
$tool=Join-Path $retention 'memwatch';New-Item -ItemType Directory -Path $tool | Out-Null
Copy-Item -LiteralPath C:/memwatch/MemWatch.ps1 -Destination (Join-Path $tool 'MemWatch.ps1')
foreach($file in Get-ChildItem C:/memwatch -File){
    if($file.Name -like 'intensive-C1001-*.csv' -or $file.Name -like 'niveau-C1001-*.txt' -or $file.Name -like 'stop-C1001-*'){Copy-Item -LiteralPath $file.FullName -Destination (Join-Path $tool $file.Name)}
}
$permanent=@(Import-Csv -LiteralPath C:/memwatch/memwatch.csv)
$start=[datetime]'2026-11-05T17:44:46';$end=[datetime]'2026-11-05T20:32:31'
@($permanent|Where-Object {$time=[datetime]::ParseExact($_.Heure,'yyyy-MM-dd HH:mm:ss',[Globalization.CultureInfo]::InvariantCulture);$time -ge $start -and $time -le $end})|Export-Csv -LiteralPath (Join-Path $tool 'permanent-lot-with-ten-minute-lookback.csv') -NoTypeInformation -Encoding utf8
Export-ScheduledTask -TaskName MemWatch | Set-Content -LiteralPath (Join-Path $tool 'scheduled-task-read-only.xml') -Encoding utf8NoBOM
$m=Get-Content -LiteralPath (Join-Path $repo 'target/native-build/cpu/C1001-cpu1/manifest.json') -Raw|ConvertFrom-Json
$cache=$m.dependencyCache.before
$cacheFiles=@(Get-NativePlainTree $cache.archives | Where-Object {-not $_.directory -and -not $_.reparse}|ForEach-Object {@{relative=$_.relative;bytes=(Get-Item -LiteralPath $_.path).Length;sha256=(Get-FileHash -LiteralPath $_.path).Hash}})
@{state='UNSEALED; NOT QUALIFIED; NOT REUSED';key=$cache.key;generation=$cache.generation;archives=$cache.archives;currentSelectorExists=(Test-Path -LiteralPath (Join-Path $cache.root 'current.json'));files=$cacheFiles}|ConvertTo-Json -Depth 6|Set-Content -LiteralPath (Join-Path $retention 'partial-cache-inventory.json') -Encoding utf8NoBOM
$inventory=Get-Content -LiteralPath (Join-Path $repo 'docs/architecture/raw/native-build/installed-inventory.json') -Raw|ConvertFrom-Json
$installed=Join-Path $env:LOCALAPPDATA 'Whisper/native'
$installedCheck=@(foreach($file in $inventory){$path=Join-Path $installed $file.RelativePath;$item=Get-Item -LiteralPath $path;$hash=(Get-FileHash -LiteralPath $path).Hash;@{relative=$file.RelativePath;bytes=$item.Length;sha256=$hash;unchanged=($hash -ieq $file.Sha256 -and $item.Length -eq $file.Size)}})
if(@($installedCheck|Where-Object {-not $_.unchanged}).Count){throw 'Installed DLL differs from the reference inventory; preserve and report.'}
$installedCheck|ConvertTo-Json -Depth 5|Set-Content -LiteralPath (Join-Path $retention 'installed-dlls-final.json') -Encoding utf8NoBOM
@{codeCommit=(& git -C $repo --no-optional-locks rev-parse HEAD);main=(& git -C C:/dev/whisper --no-optional-locks rev-parse HEAD);protectionCandidate='1d9e7d60d7babff944e15f6b33d3d6a303755b24';sourceScriptSha256=(Get-FileHash -LiteralPath (Join-Path $repo 'ci/build-native.ps1')).Hash;noMerge=$true;noPush=$true;noInstalledReplacement=$true;noCleanup=$true}|ConvertTo-Json|Set-Content -LiteralPath (Join-Path $retention 'git-and-scope.json') -Encoding utf8NoBOM
$map=[Collections.Generic.Dictionary[string,string]]::new([StringComparer]::OrdinalIgnoreCase)
$links=[Collections.Generic.List[object]]::new()
$excluded=[Collections.Generic.List[object]]::new()
function Add-File([string]$Path,[string]$Name){
    if(-not(Test-Path -LiteralPath $Path -PathType Leaf)){return}
    if($map.ContainsKey($Name)){if($map[$Name] -ine $Path){throw "Archive name collision: $Name"};return}
    $map.Add($Name,$Path)
}
function Add-Tree([string]$Root,[string]$Prefix,[string[]]$Skip=@()){
    if(-not(Test-Path -LiteralPath $Root -PathType Container)){return}
    $pending=[Collections.Generic.Stack[string]]::new();$pending.Push($Root)
    while($pending.Count){$directory=$pending.Pop();foreach($item in Get-ChildItem -LiteralPath $directory -Force){
        $relative=[IO.Path]::GetRelativePath($Root,$item.FullName).Replace('\','/')
        if($Root -ieq $lot -and $relative -notlike '*/*' -and ($item.Name -match '^archive.*\.(stdout|stderr)\.log$' -or $item.Name -eq 'archive-result.json')){$excluded.Add(@{path=$item.FullName;reason='Archive execution capture/result excluded to avoid hashing an open or self-referential file; preserved in place.'});continue}
        if($relative -in $Skip -or ($item.PSIsContainer -and $item.Name -in @('TEMP','TMP','LOCALAPPDATA','APPDATA','HOME','USERPROFILE','CMakeFiles','collector-temp','host-env')) -or $item.Extension -in @('.index','.obj','.pdb')){$excluded.Add(@{path=$item.FullName;reason='Intermediate or explicitly excluded subtree; preserved in place.'});continue}
        if($item.Attributes -band [IO.FileAttributes]::ReparsePoint){$links.Add(@{path=$item.FullName;archiveRelative="$Prefix/$relative";type=$item.LinkType;target=@($item.Target);followed=$false});continue}
        if($item.PSIsContainer){$pending.Push($item.FullName)}else{Add-File $item.FullName "$Prefix/$relative"}
    }}
}
Add-Tree $lot 'lot'
Add-Tree (Join-Path $repo 'target/native-build/cpu/C1001-cpu1') 'cpu1' @('temp')
Add-Tree (Join-Path $repo 'target/native-build/guard/NativeDllCpu-C1001-cpu1') 'cpu1-guard' @('previous-workspace','temp','localappdata','appdata','userprofile','home')
Add-Tree (Join-Path $repo 'target/native-build/supervision/C1001-cpu1') 'cpu1-supervision' @('temp')
Add-Tree (Join-Path $repo 'target/native-build/c1001-controls') 'native-controls' @('temp')
Add-Tree (Join-Path $repo 'target/native-build/guard/selftest-a544153bc66b4dffb2dbf113e0a73da8') 'native-guard-selftest'
Add-Tree (Join-Path $repo 'target/native-build/cachetest-9257788e') 'cache-selftest'
# Preserve underlying main N1 stdout/stderr, not only the outer guard capture.
foreach($file in Get-ChildItem -LiteralPath (Join-Path $lot 'protection-run2') -File -Filter '*.stdout.log'){
    $text=[IO.File]::ReadAllText($file.FullName)
    foreach($match in [regex]::Matches($text,'(?m)^N1_GUARD .+ stdout=(.+) stderr=(.+)\r?$')){
        foreach($index in @(1,2)){$path=$match.Groups[$index].Value.Trim();Add-File $path ('n1-raw/'+[IO.Path]::GetRelativePath('C:\',$path).Replace('\','/'))}
    }
}
Add-File 'C:\wb\c1001\preprocessed\any_lite.i' 'compiler/any_lite.i'
Add-File 'C:\wb\c1001\essai-0\CMakeFiles\libprotobuf.dir\src\google\protobuf\any_lite.cc.obj' 'compiler/essai-0.obj'
Add-File 'C:\wb\c1001\essai-0\stdout.log' 'compiler/essai-0.stdout.log'
Add-File 'C:\wb\c1001\essai-0\stderr.log' 'compiler/essai-0.stderr.log'
$command=Get-Content -LiteralPath (Join-Path $lot 'isolated-command.json') -Raw|ConvertFrom-Json
foreach($source in $command.sources){if((Get-FileHash -LiteralPath $source.path).Hash -cne $source.sha256){throw 'Preserved compiler input changed.'};Add-File $source.path ('compiler/source/'+[IO.Path]::GetFileName($source.path))}
foreach($file in Get-ChildItem -LiteralPath C:/wb/c1001/dumps -File){Add-File $file.FullName ('compiler/dumps/'+$file.Name)}
foreach($folder in @('environment','preprocessed','essai-0','A','A-remainder','B1','B1-synchronized')){Add-Tree (Join-Path 'C:\wb\c1001' $folder) ('compiler/runs/'+$folder) @('TEMP','TMP','LOCALAPPDATA','APPDATA','HOME','USERPROFILE','CMakeFiles')}
$trees='C:\wb\native\cpu\src\vcpkg\buildtrees'
foreach($port in Get-ChildItem -LiteralPath $trees -Directory){
    foreach($file in Get-ChildItem -LiteralPath $port.FullName -File -Force){if($file.Extension -in @('.log','.txt')){Add-File $file.FullName ("interrupted-vcpkg/$($port.Name)/$($file.Name)")}}
    foreach($build in Get-ChildItem -LiteralPath $port.FullName -Directory -Filter 'x64-*'){
        foreach($name in @('CMakeCache.txt','build.ninja','.ninja_log','.ninja_deps')){Add-File (Join-Path $build.FullName $name) ("interrupted-vcpkg/$($port.Name)/$($build.Name)/$name")}
    }
}
foreach($path in @('ci/build-native.ps1','ci/native-cache.ps1','ci/test-native-cache.ps1','ci/repro-native-compiler.ps1','ci/test-repro-native-compiler.ps1','native/build-config.json','native/patches/ggml-pinned-build-commit.patch','docs/cadrage/plan-build-natif-c1001.md','docs/cadrage/build-natif-protection-proposition.md','docs/architecture/NATIVE-BUILD.md')){Add-File (Join-Path $repo $path) ('candidate/'+$path)}
$proposal=Get-Content -LiteralPath (Join-Path $lot 'protection-proposal-v2.json') -Raw|ConvertFrom-Json
foreach($path in @($proposal.included)+@('ci/tests-baseline.txt')){Add-File (Join-Path $repo $path) ('candidate/'+$path)}
$links|ConvertTo-Json -Depth 5|Set-Content -LiteralPath (Join-Path $retention 'links-not-followed.json') -Encoding utf8NoBOM
$excluded|ConvertTo-Json -Depth 5|Set-Content -LiteralPath (Join-Path $retention 'excluded-preserved.json') -Encoding utf8NoBOM
Add-File (Join-Path $retention 'links-not-followed.json') 'retention/links-not-followed.json'
Add-File (Join-Path $retention 'excluded-preserved.json') 'retention/excluded-preserved.json'
$files=@(foreach($name in @($map.Keys|Sort-Object)){$path=$map[$name];[ordered]@{path=$name;bytes=(Get-Item -LiteralPath $path).Length;sha256=(Get-FileHash -LiteralPath $path).Hash}})
$manifest=@{schemaVersion=1;createdUtc=[datetimeoffset]::UtcNow.ToString('o');reason='WHEA stop; no new qualification';fileCount=$files.Count;totalBytes=($files|ForEach-Object {[int64]$_.bytes}|Measure-Object -Sum).Sum;files=$files}
$manifestPath=Join-Path $retention 'archive-manifest.json';$manifest|ConvertTo-Json -Depth 6|Set-Content -LiteralPath $manifestPath -Encoding utf8NoBOM
if(Test-Path -LiteralPath $zipPath){throw 'New archive path exists.'}
$zip=[IO.Compression.ZipFile]::Open($zipPath,[IO.Compression.ZipArchiveMode]::Create)
try{foreach($file in $files){[void][IO.Compression.ZipFileExtensions]::CreateEntryFromFile($zip,$map[$file.path],$file.path,[IO.Compression.CompressionLevel]::Optimal)};[void][IO.Compression.ZipFileExtensions]::CreateEntryFromFile($zip,$manifestPath,'archive-manifest.json',[IO.Compression.CompressionLevel]::Optimal)}finally{$zip.Dispose()}
$zip=[IO.Compression.ZipFile]::OpenRead($zipPath)
try{
    if($zip.Entries.Count -ne $files.Count+1){throw 'Archive file count differs.'}
    foreach($file in $files){$entry=$zip.GetEntry($file.path);if($null -eq $entry -or $entry.Length -ne $file.bytes){throw 'Archive name/size differs.'};$stream=$entry.Open();try{$sha=[Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($stream))}finally{$stream.Dispose()};if($sha -cne $file.sha256){throw "Archive digest differs: $($file.path)"}}
    $entry=$zip.GetEntry('archive-manifest.json');$stream=$entry.Open();try{$sha=[Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($stream))}finally{$stream.Dispose()};if($sha -cne (Get-FileHash -LiteralPath $manifestPath).Hash){throw 'Archive manifest differs.'}
}finally{$zip.Dispose()}
$result=@{archive=$zipPath;sha256=(Get-FileHash -LiteralPath $zipPath).Hash;zipBytes=(Get-Item -LiteralPath $zipPath).Length;files=$files.Count;plusManifest=1;uncompressedBytes=$manifest.totalBytes;verifiedNamesSizesAndSha256=$true;linksNotFollowed=$links.Count;excludedPreserved=$excluded.Count;installedDllsUnchanged=$installedCheck.Count;cleanupExecuted=$false}
$result|ConvertTo-Json|Set-Content -LiteralPath (Join-Path $lot 'archive-result.json') -Encoding utf8NoBOM
$result|ConvertTo-Json
