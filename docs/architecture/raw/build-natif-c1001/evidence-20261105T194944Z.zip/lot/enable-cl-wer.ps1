#Requires -Version 7.0
#Requires -RunAsAdministrator
# Run by the user in an administrator PowerShell. The Codex session never elevates itself.
# Microsoft: https://learn.microsoft.com/en-us/windows/win32/wer/collecting-user-mode-dumps
$ErrorActionPreference='Stop'
$key='HKLM:\SOFTWARE\Microsoft\Windows\Windows Error Reporting\LocalDumps\cl.exe'
$parent=Split-Path $key
$folder='C:\wb\c1001\dumps'
$receipt='C:\wt\build-natif\target\build-natif-c1001\wer-setup.json'
if(Test-Path -LiteralPath $key){throw 'cl.exe LocalDumps key already exists. Nothing overwritten; ask the session to inspect it.'}
if(Test-Path -LiteralPath $receipt){throw 'WER receipt already exists. Nothing overwritten.'}
$cursor=$folder
while($cursor){
    if((Test-Path -LiteralPath $cursor) -and ((Get-Item -LiteralPath $cursor -Force).Attributes -band [IO.FileAttributes]::ReparsePoint)){throw "Reparse point refused: $cursor"}
    $cursor=Split-Path $cursor -Parent
}
New-Item -ItemType Directory -Path $folder -Force | Out-Null
$parentExisted=Test-Path -LiteralPath $parent
if(-not $parentExisted){New-Item -Path $parent -ErrorAction Stop | Out-Null}
New-Item -Path $key -ErrorAction Stop | Out-Null
New-ItemProperty -LiteralPath $key -Name DumpFolder -Value $folder -PropertyType ExpandString -ErrorAction Stop | Out-Null
New-ItemProperty -LiteralPath $key -Name DumpType -Value 2 -PropertyType DWord -ErrorAction Stop | Out-Null
New-ItemProperty -LiteralPath $key -Name DumpCount -Value 512 -PropertyType DWord -ErrorAction Stop | Out-Null
$observed=Get-ItemProperty -LiteralPath $key
if($observed.DumpFolder -cne $folder -or $observed.DumpType -ne 2 -or $observed.DumpCount -ne 512){throw 'WER values differ; do not compile. The created key was not removed.'}
[ordered]@{
    configuredUtc=[datetimeoffset]::UtcNow.ToString('o');key=$key;keyExistedBefore=$false;parentExistedBefore=$parentExisted
    dumpFolder=$folder;dumpType=2;dumpCount=512;administratorAction='manual user command, no agent elevation';aclChanged=$false
    removalProposal="Remove-Item -LiteralPath '$key'"
    note='Removal only after the lot and user decision; does not remove dumps or any existing global WER settings.'
} | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath $receipt -Encoding utf8NoBOM
'WER cl.exe configured: full dumps, count 512. Return to the session for non-admin verification before cl.exe.'
