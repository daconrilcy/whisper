param([switch]$InventaireSeul)
$ErrorActionPreference = 'Stop'
$dir = Join-Path $PSScriptRoot ('opengl-' + (Get-Date -Format yyyyMMdd-HHmmss) + '-' + [guid]::NewGuid().ToString('N').Substring(0,6))
New-Item -ItemType Directory -Path $dir | Out-Null
$report = Join-Path $dir 'rapport-opengl.txt'
function Note([string]$line) {
    $line | Out-File -LiteralPath $report -Encoding utf8 -Append
    Write-Host $line
}
function Section([string]$name, [scriptblock]$query) {
    Note ("--- {0} ---" -f $name)
    try {
        $items = @(& $query)
        if ($items.Count) { Note (($items | Format-List | Out-String -Width 200).Trim()) }
        else { Note 'Aucune entree retournee.' }
    } catch { Note ('Lecture indisponible : ' + $_.Exception.Message) }
}
Note ('Diagnostic graphique Whisper | ' + (Get-Date -Format o))
Note ('Session Windows : ' + $env:SESSIONNAME + ' | ID ' + (Get-Process -Id $PID).SessionId)
Section 'Connexion selon Windows (un outil de prise en main peut partager la console)' {
    Add-Type -AssemblyName System.Windows.Forms
    [pscustomobject]@{TerminalServerSession=[Windows.Forms.SystemInformation]::TerminalServerSession}
}
Section 'Windows' { Get-CimInstance Win32_OperatingSystem | Select-Object Caption,Version,BuildNumber,OSArchitecture }
Section 'CPU' { Get-CimInstance Win32_Processor | Select-Object Name,Architecture }
Section 'Adaptateurs graphiques' { Get-CimInstance Win32_VideoController | Select-Object Name,DriverVersion,Status,ConfigManagerErrorCode,CurrentHorizontalResolution,CurrentVerticalResolution,InstalledDisplayDrivers }
Section 'Pilotes Windows de classe DISPLAY' { Get-CimInstance Win32_PnPSignedDriver -Filter "DeviceClass='DISPLAY'" | Select-Object DeviceName,DriverProviderName,DriverVersion,DriverDate,InfName }
Section 'Paquet de compatibilite graphique visible pour cet utilisateur' { Get-AppxPackage -Name 'Microsoft.D3DMappingLayers' | Select-Object Name,Version,Architecture }
function Test-Desktop {
    $desktop = Join-Path $env:LOCALAPPDATA 'WhisperTurbo\app\whisper-desktop.exe'
    if (!(Test-Path -LiteralPath $desktop -PathType Leaf)) { Note 'Desktop installe absent. Verifier l installation avec DIAGNOSTIC.ps1.'; return }
    $hash = (Get-FileHash -LiteralPath $desktop -Algorithm SHA256).Hash
    Note ("Desktop SHA256 : " + $hash)
    if ($hash -ine '01e2ea8ba221ed3245b9227c2fdb2bd5a36da073bff8305b255ad4dfe1be1f48') { Note 'Candidat different. Essai non lance.'; return }
    if (Get-Process whisper-desktop -ErrorAction SilentlyContinue) { Note 'Whisper deja ouvert. Fermez-le normalement puis relancez le diagnostic.'; return }
    $errfile = Join-Path $dir 'stderr.txt'
    $outfile = Join-Path $dir 'stdout.txt'
    $child = Start-Process -FilePath $desktop -WorkingDirectory (Split-Path $desktop) -PassThru -RedirectStandardOutput $outfile -RedirectStandardError $errfile
    Note ("PID du desktop x64 verifie : " + $child.Id)
    if (!$child.WaitForExit(15000)) { Note 'Processus encore actif apres 15 s. Indiquez si la fenetre est utilisable. Les sorties restent dans ce dossier.'; return }
    $child.WaitForExit()
    $msg = [IO.File]::ReadAllText($errfile)
    Note ('Sortie standard : ' + [IO.File]::ReadAllText($outfile))
    Note ('Sortie erreur : ' + $msg)
    if ($msg -match 'egui_glow requires opengl 2\.0\+') {
        Note 'CONFIRME : le contexte obtenu par le desktop x64 dans cette session annonce OpenGL < 2. Le blocage est dans l initialisation graphique.'
    } else { Note 'Desktop termine sans la signature OpenGL attendue. Examiner les sorties avant de conclure.' }
}
if (!$InventaireSeul) {
    try { Test-Desktop } catch { Note ('Essai indisponible : ' + $_.Exception.Message) }
} else { Note 'Inventaire seul. Desktop non lance.' }
Note 'Indiquez avec le rapport si vous utilisiez l ecran physique, le Bureau a distance ou un autre outil de connexion.'
Note 'Si le test echoue a distance et que vous avez acces a la console physique, refaites exactement la meme commande sur la console avec le meme compte. Chaque essai conserve son rapport.'
Note 'Une difference entre sessions localise une condition de reproduction. Le nom du pilote ou la presence du paquet de compatibilite ne prouvent pas quelle implementation OpenGL a ete chargee.'
Write-Host ("Rapport a transmettre : " + $report)
